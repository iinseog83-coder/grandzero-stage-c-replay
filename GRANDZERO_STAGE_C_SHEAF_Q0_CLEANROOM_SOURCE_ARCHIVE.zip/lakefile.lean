import Lake
open Lake DSL

package «gz_stage_c_sheaf_q0» where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

lean_lib «StageA» where
  roots := #[`StageA]

lean_lib «StageB» where
  roots := #[`StageB]

lean_lib «StageC» where
  roots := #[`StageC]

@[default_target]
lean_exe «stage_c_audit» where
  root := `Main

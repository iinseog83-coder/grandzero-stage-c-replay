/-
  GRANDZERO Ω — Stage B (Minimal 3-Context · 1-Triangle 2-Cell Certifier)
  Module B-3: Q0ConeEmptyOverlap.lean
  Scope:
    Soundness-first global empty-overlap refutation (`EmptyOverlapCertQ0`,
    `F-PHCA-B01` & `Tribunal Refinement 2.C`):
      1. `coneContradiction`: dimensionally-balanced rational Farkas / preordering
         combinations of certified `pos` guards, certified `nonNeg` guards (including
         pole-checked squares `gSqNNeg`), and equality-ideal multipliers reducing via
         `StageA.reflectExpr` to a non-positive / negative rational constant.
      2. `zeroGuardContradiction`: certified `nonZero` expression plus equality-ideal
         combination reducing to canonical polynomial `0`.
    Explicitly sound and conservative (`Sound, Not Complete` over nonlinear `ℚ` constraints).
-/

import StageB.Q0TypedTransportAndPullback

namespace GrandZero.StageB

open GrandZero.StageA

/-! ### Part 1: Degree-0 Constant Extraction on `PolyQ0` -/

/-- Extract an exact rational constant if `canonPoly p` has degree `0`. -/
def asConstRat (p : PolyQ0) : Option Rat :=
  match canonPoly p with
  | ⟨[]⟩        => some 0
  | ⟨[([], c)]⟩ => some c
  | _           => none

theorem lem_asConstRat_sound {p : PolyQ0} {c : Rat}
    (h : asConstRat p = some c) (ρ : List Rat) :
    evalPoly ρ p = c := by
  unfold asConstRat at h
  rw [← evalPoly_canonPoly ρ p]
  cases hcp : canonPoly p with
  | mk ts =>
      rw [hcp] at h
      cases ts with
      | nil =>
          simp only [Option.some.injEq] at h
          subst h
          rfl
      | cons hd tl =>
          rcases hd with ⟨m, c0⟩
          cases m with
          | nil =>
              cases tl with
              | nil =>
                  simp only [Option.some.injEq] at h
                  subst h
                  simp [evalPoly, evalTerms, evalMonom, Rat.mul_one, Rat.add_zero]
              | cons _ _ => contradiction
          | cons _ _ => contradiction

/-! ### Part 2: Dimensionally-Typed Cone & Ideal Witness Terms -/

/-- Strictly positive weighted witness term `(c_k > 0)_{u_k} * a_k` normalizing to `unitless`. -/
structure PosConeTermQ0 where
  weight     : Rat
  weightUnit : UnitSpecQ0
  expr       : ExprQ0
  proof      : BridgeGuardProofQ0
  deriving DecidableEq, Repr, Inhabited

/-- Non-negative weighted witness term `(d_ℓ ≥ 0)_{v_ℓ} * b_ℓ` normalizing to `unitless`
    (supports linear guards, guard products, and pole-verified squares `.gSqNNeg`). -/
structure NNegConeTermQ0 where
  weight     : Rat
  weightUnit : UnitSpecQ0
  expr       : ExprQ0
  proof      : BridgeGuardProofQ0
  deriving DecidableEq, Repr, Inhabited

/-- Equality-ideal multiplier term `multExpr * (lhs_r - rhs_r)` normalizing to `targetUnit`. -/
structure EqIdealTermQ0 where
  hypIdx         : Nat
  multExpr       : ExprQ0
  multPoleProofs : List GuardProofQ0
  deriving DecidableEq, Repr, Inhabited

def posTermExpr (t : PosConeTermQ0) : ExprQ0 :=
  .binOp .mul (.ratLit t.weight t.weightUnit) t.expr

def nnegTermExpr (t : NNegConeTermQ0) : ExprQ0 :=
  .binOp .mul (.ratLit t.weight t.weightUnit) t.expr

def checkPosConeTerm (C : ContextQ0) (t : PosConeTermQ0) : Bool :=
  decide (0 < t.weight) &&
  checkBridgeGuardProof C.vars C.hyps C.guards t.proof (.pos t.expr) &&
  (synthUnit C.vars (posTermExpr t) == some UnitSpecQ0.unitless)

def checkNNegConeTerm (C : ContextQ0) (t : NNegConeTermQ0) : Bool :=
  decide (0 ≤ t.weight) &&
  checkBridgeGuardProof C.vars C.hyps C.guards t.proof (.nonNeg t.expr) &&
  (synthUnit C.vars (nnegTermExpr t) == some UnitSpecQ0.unitless)

def buildEqIdealExpr (C : ContextQ0) (t : EqIdealTermQ0) : Option ExprQ0 :=
  match C.hyps[t.hypIdx]? with
  | some (.eqProp lhs rhs) => some (.binOp .mul t.multExpr (.binOp .sub lhs rhs))
  | none                   => none

def checkEqIdealTerm (C : ContextQ0) (targetUnit : UnitSpecQ0) (t : EqIdealTermQ0) : Bool :=
  match C.hyps[t.hypIdx]?, reflectExpr C.vars t.multExpr with
  | some (.eqProp lhs rhs), some rm =>
      checkGuardListProofs C.vars C.hyps C.guards t.multPoleProofs rm.guards &&
      (synthUnit C.vars (.binOp .mul t.multExpr (.binOp .sub lhs rhs)) == some targetUnit)
  | _, _ => false

theorem lem_posConeTerm_sound {C : ContextQ0} {t : PosConeTermQ0} {ρ : List Rat}
    (hvalid : ValidDomainQ0 ρ C)
    (ht : checkPosConeTerm C t = true) :
    synthUnit C.vars (posTermExpr t) = some UnitSpecQ0.unitless ∧
    ∃ v : Rat, denoteExpr ρ (posTermExpr t) = some v ∧ 0 < v := by
  rcases hvalid with ⟨henv, hhyps, hguards⟩
  unfold checkPosConeTerm at ht
  simp only [Bool.and_eq_true, decide_eq_true_eq, beq_iff_eq] at ht
  rcases ht with ⟨⟨hw_pos, hprf⟩, hunit⟩
  have hev := (thm_bridge_guard_proof_sound C.vars C.hyps C.guards ρ henv hhyps hguards
    t.proof (.pos t.expr) hprf).2
  rcases (evalGuard_pos_iff ρ t.expr).mp hev with ⟨ve, hde, hve_pos⟩
  refine ⟨hunit, t.weight * ve, ?_, Rat.mul_pos hw_pos hve_pos⟩
  simp [posTermExpr, denoteExpr, evalBinOp, hde]

theorem lem_nnegConeTerm_sound {C : ContextQ0} {t : NNegConeTermQ0} {ρ : List Rat}
    (hvalid : ValidDomainQ0 ρ C)
    (ht : checkNNegConeTerm C t = true) :
    synthUnit C.vars (nnegTermExpr t) = some UnitSpecQ0.unitless ∧
    ∃ v : Rat, denoteExpr ρ (nnegTermExpr t) = some v ∧ 0 ≤ v := by
  rcases hvalid with ⟨henv, hhyps, hguards⟩
  unfold checkNNegConeTerm at ht
  simp only [Bool.and_eq_true, decide_eq_true_eq, beq_iff_eq] at ht
  rcases ht with ⟨⟨hw_nn, hprf⟩, hunit⟩
  have hev := (thm_bridge_guard_proof_sound C.vars C.hyps C.guards ρ henv hhyps hguards
    t.proof (.nonNeg t.expr) hprf).2
  rcases (evalGuard_nonNeg_iff ρ t.expr).mp hev with ⟨ve, hde, hve_nn⟩
  refine ⟨hunit, t.weight * ve, ?_, Rat.mul_nonneg hw_nn hve_nn⟩
  simp [nnegTermExpr, denoteExpr, evalBinOp, hde]

theorem lem_eqIdealTerm_sound {C : ContextQ0} {u : UnitSpecQ0} {t : EqIdealTermQ0} {ρ : List Rat}
    (hvalid : ValidDomainQ0 ρ C)
    (ht : checkEqIdealTerm C u t = true) :
    ∃ e_eq : ExprQ0,
      buildEqIdealExpr C t = some e_eq ∧
      synthUnit C.vars e_eq = some u ∧
      denoteExpr ρ e_eq = some 0 := by
  rcases hvalid with ⟨henv, hhyps, hguards⟩
  unfold checkEqIdealTerm at ht
  cases hget : C.hyps[t.hypIdx]? with
  | none => rw [hget] at ht; contradiction
  | some ψ =>
      rw [hget] at ht
      cases ψ with
      | eqProp lhs rhs =>
          cases hrm : reflectExpr C.vars t.multExpr with
          | none => rw [hrm] at ht; contradiction
          | some rm =>
              rw [hrm] at ht
              simp only [Bool.and_eq_true, beq_iff_eq] at ht
              rcases ht with ⟨hpole, hunit⟩
              have hg_rm := thm_guard_list_sound C.vars C.hyps C.guards ρ henv hhyps hguards
                t.multPoleProofs rm.guards hpole
              have hm_some := (thm_gpr_domain_exact t.multExpr C.vars ρ rm henv hrm).mp hg_rm
              cases hdm : denoteExpr ρ t.multExpr with
              | none => rw [hdm] at hm_some; contradiction
              | some vm =>
                  have hψ := hhyps (.eqProp lhs rhs) (List.mem_of_getElem? hget)
                  simp only [denoteProp] at hψ
                  cases hdl : denoteExpr ρ lhs with
                  | none => rw [hdl] at hψ; contradiction
                  | some vl =>
                    cases hdr : denoteExpr ρ rhs with
                    | none => rw [hdl, hdr] at hψ; contradiction
                    | some vr =>
                        rw [hdl, hdr] at hψ
                        simp only [Option.some.injEq, decide_eq_true_eq] at hψ
                        subst hψ
                        refine ⟨.binOp .mul t.multExpr (.binOp .sub lhs rhs), ?_, hunit, ?_⟩
                        · simp [buildEqIdealExpr, hget]
                        · have hsub0 : vl - vl = 0 := by grind
                          simp [denoteExpr, evalBinOp, hdm, hdl, hdr, hsub0, Rat.mul_zero]

/-! ### Part 3: Summation Helpers Preserving `UnitSpecQ0` and Sign -/

def sumPosConeExprs : List PosConeTermQ0 → ExprQ0
  | []      => .ratLit 0 UnitSpecQ0.unitless
  | [t]     => posTermExpr t
  | t :: ts => .binOp .add (posTermExpr t) (sumPosConeExprs ts)

theorem lem_sumPosConeExprs_sound {C : ContextQ0} {ρ : List Rat}
    (hvalid : ValidDomainQ0 ρ C) :
    ∀ (ts : List PosConeTermQ0),
      ts.all (checkPosConeTerm C) = true →
      synthUnit C.vars (sumPosConeExprs ts) = some UnitSpecQ0.unitless ∧
      ∃ v : Rat,
        denoteExpr ρ (sumPosConeExprs ts) = some v ∧
        (ts ≠ [] → 0 < v) ∧ (ts = [] → v = 0)
  | [], _ =>
      ⟨rfl, 0, rfl, fun h => False.elim (h rfl), fun _ => rfl⟩
  | [t], h => by
      simp only [List.all_cons, List.all_nil, Bool.and_true] at h
      rcases lem_posConeTerm_sound hvalid h with ⟨hu, v, hdv, hv_pos⟩
      exact ⟨hu, v, hdv, fun _ => hv_pos, fun hnil => by contradiction⟩
  | t1 :: t2 :: rest, h => by
      simp only [List.all_cons, Bool.and_eq_true] at h
      rcases lem_posConeTerm_sound hvalid h.1 with ⟨hu1, v1, hdv1, hv1_pos⟩
      have htail_all : (t2 :: rest).all (checkPosConeTerm C) = true := by
        simp [List.all_cons, h.2.1, h.2.2]
      rcases lem_sumPosConeExprs_sound hvalid (t2 :: rest) htail_all with
        ⟨hu_rest, v2, hdv2, hv2_pos_fn, _⟩
      have hv2_pos : 0 < v2 := hv2_pos_fn (by simp)
      refine ⟨?_, v1 + v2, ?_, fun _ => rat_add_pos_pos hv1_pos hv2_pos, fun hnil => by contradiction⟩
      · simp [sumPosConeExprs, synthUnit, hu1, hu_rest, synthBinOpUnit]
      · simp [sumPosConeExprs, denoteExpr, evalBinOp, hdv1, hdv2]

def sumNNegConeExprs : List NNegConeTermQ0 → ExprQ0
  | []      => .ratLit 0 UnitSpecQ0.unitless
  | t :: ts => .binOp .add (nnegTermExpr t) (sumNNegConeExprs ts)

theorem lem_sumNNegConeExprs_sound {C : ContextQ0} {ρ : List Rat}
    (hvalid : ValidDomainQ0 ρ C) :
    ∀ (ts : List NNegConeTermQ0),
      ts.all (checkNNegConeTerm C) = true →
      synthUnit C.vars (sumNNegConeExprs ts) = some UnitSpecQ0.unitless ∧
      ∃ v : Rat, denoteExpr ρ (sumNNegConeExprs ts) = some v ∧ 0 ≤ v
  | [], _ => ⟨rfl, 0, rfl, by grind⟩
  | t :: ts, h => by
      simp only [List.all_cons, Bool.and_eq_true] at h
      rcases lem_nnegConeTerm_sound hvalid h.1 with ⟨hu1, v1, hdv1, hv1_nn⟩
      rcases lem_sumNNegConeExprs_sound hvalid ts h.2 with ⟨hu2, v2, hdv2, hv2_nn⟩
      refine ⟨?_, v1 + v2, ?_, rat_add_nonneg_nonneg hv1_nn hv2_nn⟩
      · simp [sumNNegConeExprs, synthUnit, hu1, hu2, synthBinOpUnit]
      · simp [sumNNegConeExprs, denoteExpr, evalBinOp, hdv1, hdv2]

def buildSumEqIdealExpr (C : ContextQ0) (targetUnit : UnitSpecQ0) : List EqIdealTermQ0 → Option ExprQ0
  | [] => some (.ratLit 0 targetUnit)
  | t :: ts =>
      match buildEqIdealExpr C t, buildSumEqIdealExpr C targetUnit ts with
      | some e1, some erest => some (.binOp .add e1 erest)
      | _, _                => none

theorem lem_sumEqIdealExpr_sound {C : ContextQ0} {u : UnitSpecQ0} {ρ : List Rat}
    (hvalid : ValidDomainQ0 ρ C) :
    ∀ (ts : List EqIdealTermQ0),
      ts.all (checkEqIdealTerm C u) = true →
      ∃ e_sum : ExprQ0,
        buildSumEqIdealExpr C u ts = some e_sum ∧
        synthUnit C.vars e_sum = some u ∧
        denoteExpr ρ e_sum = some 0
  | [], _ => ⟨.ratLit 0 u, rfl, rfl, rfl⟩
  | t :: ts, h => by
      simp only [List.all_cons, Bool.and_eq_true] at h
      rcases lem_eqIdealTerm_sound hvalid h.1 with ⟨e1, hb1, hu1, hd1⟩
      rcases lem_sumEqIdealExpr_sound hvalid ts h.2 with ⟨e2, hb2, hu2, hd2⟩
      refine ⟨.binOp .add e1 e2, ?_, ?_, ?_⟩
      · simp [buildSumEqIdealExpr, hb1, hb2]
      · simp [synthUnit, hu1, hu2, synthBinOpUnit]
      · simp [denoteExpr, evalBinOp, hd1, hd2, Rat.zero_add]

/-! ### Part 4: `EmptyOverlapCertQ0` & Global Emptiness Soundness (`thm_empty_overlap_sound`) -/

/-- Conservative algebraic certificate proving `Real_ℚ(C) = ∅` (`F-PHCA-B01`, `Tribunal 2.C`). -/
inductive EmptyOverlapCertQ0 where
  | coneContradiction
      (posTerms  : List PosConeTermQ0)
      (nnegTerms : List NNegConeTermQ0)
      (eqTerms   : List EqIdealTermQ0)
  | zeroGuardContradiction
      (nzExpr    : ExprQ0)
      (nzProof   : BridgeGuardProofQ0)
      (eqTerms   : List EqIdealTermQ0)
  deriving DecidableEq, Repr, Inhabited

/-- Whitebox checker for `EmptyOverlapCertQ0`. -/
def checkEmptyOverlapCert (C : ContextQ0) : EmptyOverlapCertQ0 → Bool
  | .coneContradiction posTerms nnegTerms eqTerms =>
      if !(posTerms.all (checkPosConeTerm C) &&
           nnegTerms.all (checkNNegConeTerm C) &&
           eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless)) then
        false
      else
        match buildSumEqIdealExpr C UnitSpecQ0.unitless eqTerms with
        | none => false
        | some e_eq =>
            let S := ExprQ0.binOp .add
              (.binOp .add (sumPosConeExprs posTerms) (sumNNegConeExprs nnegTerms))
              e_eq
            match reflectExpr C.vars S with
            | none => false
            | some rS =>
                match asConstRat rS.num, asConstRat rS.den with
                | some c_num, some c_den =>
                    if c_den == 0 then false
                    else
                      let q0 := c_num / c_den
                      if !posTerms.isEmpty then decide (q0 ≤ 0)
                      else decide (q0 < 0)
                | _, _ => false
  | .zeroGuardContradiction nzExpr nzProof eqTerms =>
      match synthUnit C.vars nzExpr with
      | none => false
      | some u_nz =>
          if !(checkBridgeGuardProof C.vars C.hyps C.guards nzProof (.nonZero nzExpr) &&
               eqTerms.all (checkEqIdealTerm C u_nz)) then
            false
          else
            match buildSumEqIdealExpr C u_nz eqTerms with
            | none => false
            | some e_eq =>
                let S_nz := ExprQ0.binOp .add nzExpr e_eq
                match reflectExpr C.vars S_nz with
                | none => false
                | some rS => canonPoly rS.num == PolyQ0.zero

/-- Target Theorem `THM-EMPTY-OVERLAP-SOUND` (`F-PHCA-B01`, `Tribunal Refinement 2.C`):
    Any accepted `EmptyOverlapCertQ0` proves universally over `ℚ` that NO rational point `ρ`
    belongs to `Real_ℚ(C)` (`∀ ρ, ¬ ValidDomainQ0 ρ C`).
    Note: Soundness-only certifier; completeness over arbitrary nonlinear `ℚ` ideals/cones is NOT claimed. -/
theorem thm_empty_overlap_sound
    (C : ContextQ0) (cert : EmptyOverlapCertQ0)
    (hchk : checkEmptyOverlapCert C cert = true) :
    ∀ ρ : List Rat, ¬ ValidDomainQ0 ρ C := by
  intro ρ hvalid
  have henv : EnvModelsCtx ρ C.vars := hvalid.1
  cases cert with
  | coneContradiction posTerms nnegTerms eqTerms =>
      simp only [checkEmptyOverlapCert] at hchk
      by_cases hall : !(posTerms.all (checkPosConeTerm C) &&
                        nnegTerms.all (checkNNegConeTerm C) &&
                        eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless))
      · simp [hall] at hchk
      · simp only [hall, Bool.false_eq_true, ↓reduceIte] at hchk
        have hall_pos : posTerms.all (checkPosConeTerm C) = true ∧
                        nnegTerms.all (checkNNegConeTerm C) = true ∧
                        eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless) = true := by
          cases h1 : posTerms.all (checkPosConeTerm C) <;>
          cases h2 : nnegTerms.all (checkNNegConeTerm C) <;>
          cases h3 : eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless) <;>
          simp [h1, h2, h3] at hall ⊢
        rcases lem_sumPosConeExprs_sound hvalid posTerms hall_pos.1 with
          ⟨_, v_pos, hd_pos, hpos_if_ne, hpos_if_nil⟩
        rcases lem_sumNNegConeExprs_sound hvalid nnegTerms hall_pos.2.1 with
          ⟨_, v_nn, hd_nn, hnn_ge⟩
        rcases lem_sumEqIdealExpr_sound hvalid eqTerms hall_pos.2.2 with
          ⟨e_eq, hb_eq, _, hd_eq⟩
        rw [hb_eq] at hchk
        dsimp only at hchk
        let S := ExprQ0.binOp .add
          (.binOp .add (sumPosConeExprs posTerms) (sumNNegConeExprs nnegTerms))
          e_eq
        have hd_S : denoteExpr ρ S = some ((v_pos + v_nn) + 0) := by
          simp [S, denoteExpr, evalBinOp, hd_pos, hd_nn, hd_eq]
        cases hrS : reflectExpr C.vars S with
        | none => simp [S] at hrS; rw [hrS] at hchk; contradiction
        | some rS =>
            have hrS' : reflectExpr C.vars (ExprQ0.binOp .add
              (.binOp .add (sumPosConeExprs posTerms) (sumNNegConeExprs nnegTerms)) e_eq) = some rS := hrS
            rw [hrS'] at hchk
            dsimp only at hchk
            have hg_S : GuardsHold ρ rS.guards :=
              (thm_gpr_domain_exact S C.vars ρ rS henv hrS).mpr (by simp [hd_S])
            rcases thm_gpr_value_sound S C.vars ρ rS henv hrS hg_S with ⟨_, hval_S⟩
            cases hcN : asConstRat rS.num with
            | none => rw [hcN] at hchk; contradiction
            | some c_num =>
              cases hcD : asConstRat rS.den with
              | none => rw [hcN, hcD] at hchk; contradiction
              | some c_den =>
                  rw [hcN, hcD] at hchk
                  dsimp only at hchk
                  by_cases hcd0 : c_den == 0
                  · simp [hcd0] at hchk
                  · simp only [hcd0, Bool.false_eq_true, ↓reduceIte] at hchk
                    have hevN := lem_asConstRat_sound hcN ρ
                    have hevD := lem_asConstRat_sound hcD ρ
                    rw [hevN, hevD] at hval_S
                    rw [hd_S] at hval_S
                    injection hval_S with hv_eq
                    cases hne : posTerms.isEmpty with
                    | false =>
                        simp only [hne, Bool.not_false, ↓reduceIte, decide_eq_true_eq] at hchk
                        have hnot_nil : posTerms ≠ [] := by
                          intro hnil; subst hnil; contradiction
                        have hv_p := hpos_if_ne hnot_nil
                        grind
                    | true =>
                        simp only [hne, Bool.not_true, Bool.false_eq_true, ↓reduceIte, decide_eq_true_eq] at hchk
                        have hnil : posTerms = [] := List.isEmpty_iff.mp hne
                        have hv_0 := hpos_if_nil hnil
                        grind
  | zeroGuardContradiction nzExpr nzProof eqTerms =>
      simp only [checkEmptyOverlapCert] at hchk
      cases hsu : synthUnit C.vars nzExpr with
      | none => rw [hsu] at hchk; contradiction
      | some u_nz =>
          rw [hsu] at hchk
          dsimp only at hchk
          by_cases hall : !(checkBridgeGuardProof C.vars C.hyps C.guards nzProof (.nonZero nzExpr) &&
                            eqTerms.all (checkEqIdealTerm C u_nz))
          · simp [hall] at hchk
          · simp only [hall, Bool.false_eq_true, ↓reduceIte] at hchk
            have hall_ok : checkBridgeGuardProof C.vars C.hyps C.guards nzProof (.nonZero nzExpr) = true ∧
                           eqTerms.all (checkEqIdealTerm C u_nz) = true := by
              cases h1 : checkBridgeGuardProof C.vars C.hyps C.guards nzProof (.nonZero nzExpr) <;>
              cases h2 : eqTerms.all (checkEqIdealTerm C u_nz) <;>
              simp [h1, h2] at hall ⊢
            have hev_nz := (thm_bridge_guard_proof_sound C.vars C.hyps C.guards ρ
              hvalid.1 hvalid.2.1 hvalid.2.2 nzProof (.nonZero nzExpr) hall_ok.1).2
            rcases (evalGuard_nonZero_iff ρ nzExpr).mp hev_nz with ⟨v_nz, hd_nz, hv_nz⟩
            rcases lem_sumEqIdealExpr_sound hvalid eqTerms hall_ok.2 with
              ⟨e_eq, hb_eq, _, hd_eq⟩
            rw [hb_eq] at hchk
            dsimp only at hchk
            let S_nz := ExprQ0.binOp .add nzExpr e_eq
            have hd_S : denoteExpr ρ S_nz = some (v_nz + 0) := by
              simp [S_nz, denoteExpr, evalBinOp, hd_nz, hd_eq]
            cases hrS : reflectExpr C.vars S_nz with
            | none => simp [S_nz] at hrS; rw [hrS] at hchk; contradiction
            | some rS =>
                have hrS' : reflectExpr C.vars (ExprQ0.binOp .add nzExpr e_eq) = some rS := hrS
                rw [hrS'] at hchk
                dsimp only at hchk
                simp only [beq_iff_eq] at hchk
                have hg_S : GuardsHold ρ rS.guards :=
                  (thm_gpr_domain_exact S_nz C.vars ρ rS henv hrS).mpr (by simp [hd_S])
                rcases thm_gpr_value_sound S_nz C.vars ρ rS henv hrS hg_S with ⟨_, hval_S⟩
                have hnum0 := canonPoly_eq_zero_sound hchk ρ
                rw [hnum0, hd_S] at hval_S
                injection hval_S with hv_eq
                have hzero_div : (0 : Rat) / evalPoly ρ rS.den = 0 := by grind
                rw [hzero_div] at hv_eq
                grind

end GrandZero.StageB

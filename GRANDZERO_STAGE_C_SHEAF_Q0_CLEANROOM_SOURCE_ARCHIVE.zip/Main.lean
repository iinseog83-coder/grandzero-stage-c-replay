/-
  GRANDZERO Ω — Stage C (Finite Rational Cellular Sheaf & Global Consistency Gate)
  Structured Audit Executable (`stage_c_audit`)
  Note: Every boolean printed below is computed dynamically at runtime by the
        Lean kernel functions (zero hardcoded `"true"` literals).
-/

import StageC

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC

def main : IO Unit := do
  IO.println "========================================================================"
  IO.println "GRANDZERO OMEGA — STAGE C CELLULAR SHEAF & GLOBAL CONSISTENCY AUDIT"
  IO.println "========================================================================"

  let mut allVectorsOk := true
  for rec in stageCVectorRecords do
    let matched := decide (rec.expected = rec.actual)
    if !matched then
      allVectorsOk := false
    IO.println s!"VECTOR|ID={rec.vecId}|EXPECTED={formatStageCOutcome rec.expected}|ACTUAL={formatStageCOutcome rec.actual}|MATCH={matched}|DETAIL={rec.detail}"

  -- Live runtime evaluation of exact affine vs. nonlinear Stage B bridge gate
  let affineAccepted :=
    checkExactAffineEquiv [UnitSpecQ0.unitless] tc01_affine_stageB_expr
      (vecOfList 1 [2]) (fun _ => UnitSpecQ0.energy) 4 UnitSpecQ0.energy
  let nonlinearRejected :=
    !checkExactAffineEquiv [velUnit, invVelUnit] tc01_nonlinear_tb02_expr
      (vecOfList 2 [1, 0]) (fun i => if i.val = 0 then UnitSpecQ0.unitless else velUnit) 0 velUnit
  IO.println s!"EXTRA|ID=TC-01-AFFINE-GATE|AFFINE_ACCEPTED={affineAccepted}|NONLINEAR_TB02_REJECTED={nonlinearRejected}"

  -- Live runtime evaluation of H^1 quotient class coordinates on TC-02
  let tc02ClassNonZero := !vecEqBool (matVec tc02_cohomCert.LH tc02_eta) (zeroVec tc02_cohomCert.h1)
  let tc02CoboundaryAnnih :=
    vecEqBool (matVec tc02_cohomCert.LH (matVec (assembleDelta0 tc02_sheaf) (vecOfList 3 [3, -1, 7])))
              (zeroVec tc02_cohomCert.h1)
  IO.println s!"EXTRA|ID=TC-02-H1-QUOTIENT|COCYCLE_CLASS_NONZERO={tc02ClassNonZero}|COBOUNDARY_ANNIHILATED={tc02CoboundaryAnnih}"

  let allOk := allVectorsOk && affineAccepted && nonlinearRejected && tc02ClassNonZero && tc02CoboundaryAnnih
  IO.println "------------------------------------------------------------------------"
  IO.println s!"ALL STAGE C CELLULAR SHEAF & COHOMOLOGY VECTORS MATCH EXPECTED: {allOk}"
  if !allOk then
    throw (IO.userError "Stage C adversarial audit failed!")

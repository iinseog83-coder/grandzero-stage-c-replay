/-
  GRANDZERO Ω — Stage C (Finite Rational Cellular Sheaf & Global Consistency Gate)
  Module C-3: Q0CohomologyAndH1Quotient.lean
  Scope:
    Whitebox certification of `H⁰ = ker(δ⁰)` and first cohomology quotient
    `H¹ = ker(δ¹) / im(δ⁰) ≅ ℚ^{h¹}` via `CohomologyComplementBasis`
    (explicitly algebraic quotient-complement basis without assuming inner products
    or Hodge Laplacians, per `Tribunal §2`).
-/

import StageC.Q0CellularComplexAndSheaf

namespace GrandZero.StageC

open GrandZero.StageA
open GrandZero.StageB

/-- Algebraic `CohomologyComplementBasis` certificate for `C⁰ --δ⁰--> C¹ --δ¹--> C²`:
    - `rn0` certifies `im(δ⁰)` (rank `r0`) and `H⁰ = ker(δ⁰)` (dimension `k0 = h⁰`),
    - `rn1` certifies `ker(δ¹)` (dimension `k1`),
    - `H ∈ ℚ^{N1 × h1}` is a `CohomologyComplementBasis` inside `ker(δ¹)` with
      `ker(δ¹) = im(δ⁰) ⊕ span(H)` and class coordinate extractor `LH : ℚ^{h1 × N1}`. -/
structure CohomologyComplementBasis (N0 N1 N2 : Nat) where
  rn0 : RankNullityCertQ0 N1 N0
  rn1 : RankNullityCertQ0 N2 N1
  h1  : Nat
  H   : MatQ0 N1 h1
  LB0 : MatQ0 rn0.r N1
  LH  : MatQ0 h1 N1

/-- Computable whitebox checker for `CohomologyComplementBasis`. -/
def checkCohomologyCert {N0 N1 N2 : Nat}
    (δ0 : MatQ0 N1 N0) (δ1 : MatQ0 N2 N1)
    (cc : CohomologyComplementBasis N0 N1 N2) : Bool :=
  matEqBool (matMul δ1 δ0) (zeroMat N2 N0) &&
  checkRankNullityCert δ0 cc.rn0 &&
  checkRankNullityCert δ1 cc.rn1 &&
  decide (cc.rn0.r + cc.h1 = cc.rn1.k) &&
  matEqBool (matMul δ1 cc.H) (zeroMat N2 cc.h1) &&
  matEqBool (matMul cc.LB0 cc.rn0.B) (idMat cc.rn0.r) &&
  matEqBool (matMul cc.LB0 cc.H) (zeroMat cc.rn0.r cc.h1) &&
  matEqBool (matMul cc.LH cc.rn0.B) (zeroMat cc.h1 cc.rn0.r) &&
  matEqBool (matMul cc.LH cc.H) (idMat cc.h1) &&
  matEqBool (matMul (addMat (matMul cc.rn0.B cc.LB0) (matMul cc.H cc.LH)) cc.rn1.K) cc.rn1.K

/-- Target Theorem `thm_h0_basis_exact`:
    `cc.rn0.K` is a verified linearly independent basis of global sections `H⁰ = ker(δ⁰)`
    of dimension `h⁰ = cc.rn0.k`. -/
theorem thm_h0_basis_exact {N0 N1 N2 : Nat}
    (δ0 : MatQ0 N1 N0) (δ1 : MatQ0 N2 N1)
    (cc : CohomologyComplementBasis N0 N1 N2)
    (hcc : checkCohomologyCert δ0 δ1 cc = true) :
    (∀ α : VecQ0 cc.rn0.k, matVec δ0 (matVec cc.rn0.K α) = zeroVec N1) ∧
    (∀ α : VecQ0 cc.rn0.k, matVec cc.rn0.K α = zeroVec N0 → α = zeroVec cc.rn0.k) ∧
    (∀ x : VecQ0 N0, matVec δ0 x = zeroVec N1 → x = matVec cc.rn0.K (matVec cc.rn0.R x)) := by
  unfold checkCohomologyCert at hcc
  simp only [Bool.and_eq_true] at hcc
  have hrn0 : checkRankNullityCert δ0 cc.rn0 = true := hcc.1.1.1.1.1.1.1.1.2
  rcases thm_rank_nullity_cert_kernel_exact δ0 cc.rn0 hrn0 with ⟨_, h1, h2, h3⟩
  exact ⟨h1, h2, h3⟩

/-- Target Theorem `thm_h1_quotient_decomp_unique`:
    An accepted `CohomologyComplementBasis` proves the exact quotient characterization of
    `H¹ = ker(δ¹) / im(δ⁰) ≅ ℚ^{cc.h1}`:
      1. Dimension formula: `rank(δ⁰) + h¹ = dim ker(δ¹)`,
      2. Coboundary annihilation (`Well-defined on H¹`): `∀ x ∈ C⁰, LH (δ⁰ x) = 0`,
      3. Direct-sum cocycle decomposition: `∀ η ∈ ker(δ¹), η = δ⁰ (U₀ (LB₀ η)) + H (LH η)`,
      4. Exact coboundary criterion: `∀ η ∈ ker(δ¹), (∃ x, δ⁰ x = η) ↔ LH η = 0`,
      5. Surjectivity of class coordinates: `∀ c ∈ ℚ^{h¹}, δ¹ (H c) = 0 ∧ LH (H c) = c`. -/
theorem thm_h1_quotient_decomp_unique {N0 N1 N2 : Nat}
    (δ0 : MatQ0 N1 N0) (δ1 : MatQ0 N2 N1)
    (cc : CohomologyComplementBasis N0 N1 N2)
    (hcc : checkCohomologyCert δ0 δ1 cc = true) :
    cc.rn0.r + cc.h1 = cc.rn1.k ∧
    (∀ x : VecQ0 N0, matVec cc.LH (matVec δ0 x) = zeroVec cc.h1) ∧
    (∀ η : VecQ0 N1, matVec δ1 η = zeroVec N2 →
      η = addVec (matVec δ0 (matVec cc.rn0.U (matVec cc.LB0 η)))
                 (matVec cc.H (matVec cc.LH η))) ∧
    (∀ η : VecQ0 N1, matVec δ1 η = zeroVec N2 →
      ((∃ x : VecQ0 N0, matVec δ0 x = η) ↔ matVec cc.LH η = zeroVec cc.h1)) ∧
    (∀ c : VecQ0 cc.h1,
      matVec δ1 (matVec cc.H c) = zeroVec N2 ∧ matVec cc.LH (matVec cc.H c) = c) := by
  unfold checkCohomologyCert at hcc
  simp only [Bool.and_eq_true, decide_eq_true_eq, matEqBool_iff] at hcc
  rcases hcc with ⟨⟨⟨⟨⟨⟨⟨⟨⟨_, hrn0⟩, hrn1⟩, hdim⟩, hd1H⟩, _⟩, _⟩, hLHB0⟩, hLHH⟩, hspanK1⟩
  -- Extract `δ0 * U0 = B0` and image projection for `δ0`
  have him0 := thm_rank_nullity_cert_image_exact δ0 cc.rn0 hrn0
  have hker1 := thm_rank_nullity_cert_kernel_exact δ1 cc.rn1 hrn1
  have hB0_eq : ∀ β : VecQ0 cc.rn0.r, matVec cc.rn0.B β = matVec δ0 (matVec cc.rn0.U β) := him0.1
  have h_annih : ∀ x : VecQ0 N0, matVec cc.LH (matVec δ0 x) = zeroVec cc.h1 := by
    intro x
    have hproj : matVec δ0 (matVec cc.rn0.U (matVec cc.rn0.L (matVec δ0 x))) = matVec δ0 x :=
      (him0.2.2 (matVec δ0 x)).mp ⟨x, rfl⟩
    rw [← hproj, ← hB0_eq (matVec cc.rn0.L (matVec δ0 x)), ← matVec_matMul, hLHB0, zeroMat_vec]
  have h_decomp : ∀ η : VecQ0 N1, matVec δ1 η = zeroVec N2 →
      η = addVec (matVec δ0 (matVec cc.rn0.U (matVec cc.LB0 η)))
                 (matVec cc.H (matVec cc.LH η)) := by
    intro η hη
    have hK1R1 : η = matVec cc.rn1.K (matVec cc.rn1.R η) := hker1.2.2.2 η hη
    calc
      η = matVec cc.rn1.K (matVec cc.rn1.R η) := hK1R1
      _ = matVec (matMul (addMat (matMul cc.rn0.B cc.LB0) (matMul cc.H cc.LH)) cc.rn1.K)
            (matVec cc.rn1.R η) := by rw [hspanK1]
      _ = matVec (addMat (matMul cc.rn0.B cc.LB0) (matMul cc.H cc.LH))
            (matVec cc.rn1.K (matVec cc.rn1.R η)) := matVec_matMul _ _ _
      _ = matVec (addMat (matMul cc.rn0.B cc.LB0) (matMul cc.H cc.LH)) η := by rw [← hK1R1]
      _ = addVec (matVec (matMul cc.rn0.B cc.LB0) η) (matVec (matMul cc.H cc.LH) η) :=
            addMat_vec _ _ η
      _ = addVec (matVec cc.rn0.B (matVec cc.LB0 η)) (matVec cc.H (matVec cc.LH η)) := by
            rw [matVec_matMul, matVec_matMul]
      _ = addVec (matVec δ0 (matVec cc.rn0.U (matVec cc.LB0 η))) (matVec cc.H (matVec cc.LH η)) := by
            rw [hB0_eq (matVec cc.LB0 η)]
  refine ⟨hdim, h_annih, h_decomp, ?_, ?_⟩
  · intro η hη
    constructor
    · rintro ⟨x, rfl⟩
      exact h_annih x
    · intro hLH0
      refine ⟨matVec cc.rn0.U (matVec cc.LB0 η), ?_⟩
      have hd := h_decomp η hη
      rw [hLH0, matVec_zero, addVec_zero_right] at hd
      exact hd.symm
  · intro c
    refine ⟨?_, ?_⟩
    · rw [← matVec_matMul, hd1H, zeroMat_vec]
    · rw [← matVec_matMul, hLHH, idMat_vec]

end GrandZero.StageC

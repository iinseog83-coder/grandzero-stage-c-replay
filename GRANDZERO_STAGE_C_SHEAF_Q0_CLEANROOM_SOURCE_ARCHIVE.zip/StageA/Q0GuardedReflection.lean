/-
  GRANDZERO Ω — Stage A (M1-P0 R3) Isolated Kernel
  Module A-4: Q0GuardedReflection.lean
  Scope: Canonical Multivariate Polynomials `PolyQ0`, `GPRResultQ0`,
         `reflectExpr` (with Homogenized `letBind` Substitution & `substGuard0`),
         `reflectTape` (on `ValidTape` with `strictBind`),
         `THM-GPR-UNIT-SOUND` (Unidirectional), `THM-GPR-TYPED-TOTAL`,
         `COR-GPR-FAIL-IFF-UNTYPED`, `THM-GPR-VALUE-SOUND`, `THM-TAPE-GPR-VALUE-SOUND`,
         `THM-GPR-DOMAIN-EXACT`, `PO-TAPE-LOCALITY` for Reflection, and
         `THM-AST-TAPE-GPR-COMMUTE` (`CD-M1P0-AST-SSA-GPR`).
-/

import StageA.Q0ValidTape

namespace GrandZero.StageA

/-! ### Part 1: Elementary Field & Power Lemmas over `Rat` -/

def ratPow (q : Rat) : Nat → Rat
  | 0     => 1
  | k + 1 => q * ratPow q k

@[simp] theorem ratPow_zero (q : Rat) : ratPow q 0 = 1 := rfl
@[simp] theorem ratPow_succ (q : Rat) (k : Nat) : ratPow q (k + 1) = q * ratPow q k := rfl

theorem ratPow_one_exp (q : Rat) : ratPow q 1 = q := by
  simp [ratPow, Rat.mul_one]

theorem ratPow_add (q : Rat) : ∀ (a b : Nat), ratPow q (a + b) = ratPow q a * ratPow q b
  | 0, _ => by simp [ratPow, Rat.one_mul]
  | a + 1, b => by
      have h : a + 1 + b = (a + b) + 1 := by omega
      rw [h, ratPow_succ, ratPow_succ, ratPow_add q a b, Rat.mul_assoc]

theorem ratPow_mul_base (a b : Rat) : ∀ (k : Nat), ratPow (a * b) k = ratPow a k * ratPow b k
  | 0 => by simp [ratPow]
  | k + 1 => by
      simp only [ratPow_succ, ratPow_mul_base a b k]
      grind

theorem rat_mul_ne_zero {a b : Rat} (ha : a ≠ 0) (hb : b ≠ 0) : a * b ≠ 0 := by
  intro h
  cases Rat.mul_eq_zero.mp h with
  | inl h1 => exact ha h1
  | inr h2 => exact hb h2

theorem ratPow_ne_zero {q : Rat} (hq : q ≠ 0) : ∀ (k : Nat), ratPow q k ≠ 0
  | 0 => by simp [ratPow]
  | k + 1 => rat_mul_ne_zero hq (ratPow_ne_zero hq k)

theorem rat_div_one (q : Rat) : q / 1 = q := by grind

theorem rat_neg_div (a b : Rat) : -(a / b) = (-a) / b := by grind

theorem rat_add_frac (a b c d : Rat) (hb : b ≠ 0) (hd : d ≠ 0) :
    a / b + c / d = (a * d + c * b) / (b * d) := by grind

theorem rat_sub_frac (a b c d : Rat) (hb : b ≠ 0) (hd : d ≠ 0) :
    a / b - c / d = (a * d - c * b) / (b * d) := by grind

theorem rat_mul_frac (a b c d : Rat) (hb : b ≠ 0) (hd : d ≠ 0) :
    (a / b) * (c / d) = (a * c) / (b * d) := by grind

theorem rat_div_frac (a b c d : Rat) (hb : b ≠ 0) (hc : c ≠ 0) (hd : d ≠ 0) :
    (a / b) / (c / d) = (a * d) / (b * c) := by grind

theorem rat_div_mul_cancel (a b : Rat) (hb : b ≠ 0) : (a / b) * b = a := by grind

theorem rat_scale_frac_right (a b c : Rat) (hb : b ≠ 0) (hc : c ≠ 0) :
    (a * c) / (b * c) = a / b := by grind

theorem rat_eq_of_cross_sub_zero (a b c d : Rat) (hb : b ≠ 0) (hd : d ≠ 0)
    (h : a * d - c * b = 0) : a / b = c / d := by grind

theorem rat_div_ne_zero {a b : Rat} (ha : a ≠ 0) (hb : b ≠ 0) : a / b ≠ 0 := by
  intro h
  have h1 := rat_div_mul_cancel a b hb
  rw [h, Rat.zero_mul] at h1
  exact ha h1.symm

/-! ### Part 2: Canonical Sparse Multivariate Polynomials `PolyQ0` -/

abbrev Monom := List Nat

/-- Strip trailing zero exponents so `[1, 0, 0]` normalizes to `[1]`. -/
def trimMonom : Monom → Monom
  | [] => []
  | e :: es =>
      let t := trimMonom es
      if e = 0 ∧ t.isEmpty then [] else e :: t

/-- Evaluate a monomial exponent vector under environment `ρ`. -/
def evalMonom : List Rat → Monom → Rat
  | _, [] => 1
  | [], e :: es => (if e = 0 then 1 else 0) * evalMonom [] es
  | v :: vs, e :: es => ratPow v e * evalMonom vs es

theorem evalMonom_trimMonom : ∀ (ρ : List Rat) (m : Monom),
    evalMonom ρ (trimMonom m) = evalMonom ρ m
  | ρ, [] => rfl
  | [], e :: es => by
      simp only [trimMonom]
      split
      · rename_i h
        rcases h with ⟨he0, htemp⟩
        subst he0
        have ht : trimMonom es = [] := List.isEmpty_iff.mp htemp
        have ih := evalMonom_trimMonom [] es
        rw [ht] at ih
        simp [evalMonom, ← ih]
      · simp [evalMonom, evalMonom_trimMonom [] es]
  | v :: vs, e :: es => by
      simp only [trimMonom]
      split
      · rename_i h
        rcases h with ⟨he0, htemp⟩
        subst he0
        have ht : trimMonom es = [] := List.isEmpty_iff.mp htemp
        have ih := evalMonom_trimMonom vs es
        rw [ht] at ih
        simp [evalMonom, ← ih]
      · simp [evalMonom, evalMonom_trimMonom vs es]

/-- Componentwise exponent addition for monomial multiplication. -/
def addExps : Monom → Monom → Monom
  | [], m2 => m2
  | m1, [] => m1
  | e1 :: es1, e2 :: es2 => (e1 + e2) :: addExps es1 es2

theorem evalMonom_addExps : ∀ (ρ : List Rat) (m1 m2 : Monom),
    evalMonom ρ (addExps m1 m2) = evalMonom ρ m1 * evalMonom ρ m2
  | ρ, [], m2 => by simp [addExps, evalMonom, Rat.one_mul]
  | ρ, e1 :: es1, [] => by simp [addExps, evalMonom, Rat.mul_one]
  | [], e1 :: es1, e2 :: es2 => by
      simp only [addExps, evalMonom, evalMonom_addExps [] es1 es2]
      by_cases h1 : e1 = 0 <;> by_cases h2 : e2 = 0
      · subst h1; subst h2; simp [Rat.one_mul]
      · simp [h1, h2, Rat.zero_mul, Rat.mul_zero]
      · simp [h1, h2, Rat.zero_mul]
      · have hsum : ¬(e1 + e2 = 0) := by omega
        simp only [if_neg h1, if_neg h2, if_neg hsum, Rat.zero_mul]
  | v :: vs, e1 :: es1, e2 :: es2 => by
      simp only [addExps, evalMonom, ratPow_add, evalMonom_addExps vs es1 es2]
      grind

/-- Generator monomial for variable index `s` (`X_s`). -/
def varMonom : Nat → Monom
  | 0     => [1]
  | s + 1 => 0 :: varMonom s

theorem evalMonom_varMonom : ∀ (ρ : List Rat) (s : Nat) (hs : s < ρ.length),
    evalMonom ρ (varMonom s) = ρ[s]
  | [], _, hs => by simp at hs
  | _ :: _, 0, _ => by simp [varMonom, evalMonom, Rat.mul_one]
  | _ :: vs, s + 1, hs => by
      have hs' : s < vs.length := by simp at hs; omega
      simp [varMonom, evalMonom, Rat.one_mul, evalMonom_varMonom vs s hs']

/-- Total lexicographic ordering on trimmed monomials for canonical sorting & merging. -/
def cmpMonom : Monom → Monom → Ordering
  | [], [] => .eq
  | [], _ :: _ => .lt
  | _ :: _, [] => .gt
  | a :: as, b :: bs =>
      match compare a b with
      | .lt => .lt
      | .gt => .gt
      | .eq => cmpMonom as bs

/-- Canonical multivariate polynomial over `Rat`. -/
structure PolyQ0 where
  terms : List (Monom × Rat)
  deriving DecidableEq, Repr, Inhabited

def evalTerms (ρ : List Rat) : List (Monom × Rat) → Rat
  | [] => 0
  | (m, c) :: rest => c * evalMonom ρ m + evalTerms ρ rest

def evalPoly (ρ : List Rat) (p : PolyQ0) : Rat :=
  evalTerms ρ p.terms

theorem evalTerms_append (ρ : List Rat) : ∀ (t1 t2 : List (Monom × Rat)),
    evalTerms ρ (t1 ++ t2) = evalTerms ρ t1 + evalTerms ρ t2
  | [], t2 => by simp [evalTerms, Rat.zero_add]
  | (m, c) :: rest, t2 => by
      simp only [List.cons_append, evalTerms, evalTerms_append ρ rest]
      grind

/-- Insert a single `(m, c)` term into an ordered term list, merging identical monomials
    and dropping zero coefficients. -/
def insertTermAux (m : Monom) (c : Rat) : List (Monom × Rat) → List (Monom × Rat)
  | [] => [(m, c)]
  | (m', c') :: rest =>
      if m = m' then
        let s := c + c'
        if s = 0 then rest else (m, s) :: rest
      else
        match cmpMonom m m' with
        | .lt => (m, c) :: (m', c') :: rest
        | _   => (m', c') :: insertTermAux m c rest

def insertTerm (m_raw : Monom) (c : Rat) (ts : List (Monom × Rat)) : List (Monom × Rat) :=
  if c = 0 then ts else insertTermAux (trimMonom m_raw) c ts

theorem evalTerms_insertTermAux (ρ : List Rat) (m : Monom) (c : Rat) :
    ∀ (ts : List (Monom × Rat)),
      evalTerms ρ (insertTermAux m c ts) = c * evalMonom ρ m + evalTerms ρ ts
  | [] => by simp [insertTermAux, evalTerms, Rat.add_zero]
  | (m', c') :: rest => by
      simp only [insertTermAux]
      split
      · rename_i heq
        subst heq
        split
        · rename_i hsum0
          simp only [evalTerms]
          have h0 : (c + c') * evalMonom ρ m = 0 := by rw [hsum0, Rat.zero_mul]
          grind
        · simp only [evalTerms]
          grind
      · split
        · simp [evalTerms]
        · simp only [evalTerms, evalTerms_insertTermAux ρ m c rest]
          grind

theorem evalTerms_insertTerm (ρ : List Rat) (m_raw : Monom) (c : Rat) (ts : List (Monom × Rat)) :
    evalTerms ρ (insertTerm m_raw c ts) = c * evalMonom ρ m_raw + evalTerms ρ ts := by
  unfold insertTerm
  split
  · rename_i hc0
    subst hc0
    simp [Rat.zero_mul, Rat.zero_add]
  · rw [evalTerms_insertTermAux, evalMonom_trimMonom]

def canonTerms : List (Monom × Rat) → List (Monom × Rat)
  | [] => []
  | (m, c) :: rest => insertTerm m c (canonTerms rest)

theorem evalTerms_canonTerms (ρ : List Rat) : ∀ (ts : List (Monom × Rat)),
    evalTerms ρ (canonTerms ts) = evalTerms ρ ts
  | [] => rfl
  | (m, c) :: rest => by
      simp [canonTerms, evalTerms, evalTerms_insertTerm, evalTerms_canonTerms ρ rest]

def canonPoly (p : PolyQ0) : PolyQ0 :=
  ⟨canonTerms p.terms⟩

namespace PolyQ0

def zero : PolyQ0 := ⟨[]⟩

def const (q : Rat) : PolyQ0 :=
  if q = 0 then ⟨[]⟩ else ⟨[([], q)]⟩

def one : PolyQ0 := ⟨[([], 1)]⟩

def var (s : Nat) : PolyQ0 :=
  ⟨[(varMonom s, 1)]⟩

end PolyQ0

def polyAdd (p q : PolyQ0) : PolyQ0 :=
  ⟨canonTerms (p.terms ++ q.terms)⟩

def negTerms : List (Monom × Rat) → List (Monom × Rat)
  | [] => []
  | (m, c) :: rest => (m, -c) :: negTerms rest

def polyNeg (p : PolyQ0) : PolyQ0 :=
  ⟨canonTerms (negTerms p.terms)⟩

def polySub (p q : PolyQ0) : PolyQ0 :=
  polyAdd p (polyNeg q)

def mulTermByList (m1 : Monom) (c1 : Rat) : List (Monom × Rat) → List (Monom × Rat)
  | [] => []
  | (m2, c2) :: rest => (addExps m1 m2, c1 * c2) :: mulTermByList m1 c1 rest

def mulTermsRaw : List (Monom × Rat) → List (Monom × Rat) → List (Monom × Rat)
  | [], _ => []
  | (m1, c1) :: rest, q => mulTermByList m1 c1 q ++ mulTermsRaw rest q

def polyMul (p q : PolyQ0) : PolyQ0 :=
  ⟨canonTerms (mulTermsRaw p.terms q.terms)⟩

def polyPow (p : PolyQ0) : Nat → PolyQ0
  | 0     => PolyQ0.one
  | k + 1 => polyMul p (polyPow p k)

/-! ### Polynomial Ring Evaluation Homomorphism Lemmas -/

@[simp] theorem evalPoly_zero (ρ : List Rat) : evalPoly ρ PolyQ0.zero = 0 := rfl

@[simp] theorem evalPoly_const (ρ : List Rat) (q : Rat) :
    evalPoly ρ (PolyQ0.const q) = q := by
  unfold PolyQ0.const evalPoly
  split
  · rename_i h; exact h.symm
  · simp [evalTerms, evalMonom, Rat.mul_one, Rat.add_zero]

@[simp] theorem evalPoly_one (ρ : List Rat) : evalPoly ρ PolyQ0.one = 1 := by
  simp [PolyQ0.one, evalPoly, evalTerms, evalMonom, Rat.mul_one, Rat.add_zero]

theorem evalPoly_var (ρ : List Rat) (s : Nat) (hs : s < ρ.length) :
    evalPoly ρ (PolyQ0.var s) = ρ[s] := by
  simp [PolyQ0.var, evalPoly, evalTerms, evalMonom_varMonom ρ s hs, Rat.one_mul, Rat.add_zero]

@[simp] theorem evalPoly_canonPoly (ρ : List Rat) (p : PolyQ0) :
    evalPoly ρ (canonPoly p) = evalPoly ρ p :=
  evalTerms_canonTerms ρ p.terms

theorem canonPoly_eq_zero_sound {p : PolyQ0} (h : canonPoly p = PolyQ0.zero) (ρ : List Rat) :
    evalPoly ρ p = 0 := by
  rw [← evalPoly_canonPoly ρ p, h, evalPoly_zero]

theorem evalPoly_add (ρ : List Rat) (p q : PolyQ0) :
    evalPoly ρ (polyAdd p q) = evalPoly ρ p + evalPoly ρ q := by
  simp [polyAdd, evalPoly, evalTerms_canonTerms, evalTerms_append]

theorem evalTerms_negTerms (ρ : List Rat) : ∀ (ts : List (Monom × Rat)),
    evalTerms ρ (negTerms ts) = - evalTerms ρ ts
  | [] => by simp [negTerms, evalTerms]
  | (m, c) :: rest => by
      simp only [negTerms, evalTerms, evalTerms_negTerms ρ rest]
      grind

theorem evalPoly_neg (ρ : List Rat) (p : PolyQ0) :
    evalPoly ρ (polyNeg p) = - evalPoly ρ p := by
  simp [polyNeg, evalPoly, evalTerms_canonTerms, evalTerms_negTerms]

theorem evalPoly_sub (ρ : List Rat) (p q : PolyQ0) :
    evalPoly ρ (polySub p q) = evalPoly ρ p - evalPoly ρ q := by
  rw [polySub, evalPoly_add, evalPoly_neg]
  grind

theorem evalTerms_mulTermByList (ρ : List Rat) (m1 : Monom) (c1 : Rat) :
    ∀ (q : List (Monom × Rat)),
      evalTerms ρ (mulTermByList m1 c1 q) = (c1 * evalMonom ρ m1) * evalTerms ρ q
  | [] => by simp [mulTermByList, evalTerms, Rat.mul_zero]
  | (m2, c2) :: rest => by
      simp only [mulTermByList, evalTerms, evalMonom_addExps,
                 evalTerms_mulTermByList ρ m1 c1 rest]
      grind

theorem evalTerms_mulTermsRaw (ρ : List Rat) :
    ∀ (p q : List (Monom × Rat)),
      evalTerms ρ (mulTermsRaw p q) = evalTerms ρ p * evalTerms ρ q
  | [], _ => by simp [mulTermsRaw, evalTerms, Rat.zero_mul]
  | (m1, c1) :: rest, q => by
      simp only [mulTermsRaw, evalTerms, evalTerms_append,
                 evalTerms_mulTermByList, evalTerms_mulTermsRaw ρ rest q]
      grind

theorem evalPoly_mul (ρ : List Rat) (p q : PolyQ0) :
    evalPoly ρ (polyMul p q) = evalPoly ρ p * evalPoly ρ q := by
  simp [polyMul, evalPoly, evalTerms_canonTerms, evalTerms_mulTermsRaw]

theorem evalPoly_pow (ρ : List Rat) (p : PolyQ0) : ∀ (k : Nat),
    evalPoly ρ (polyPow p k) = ratPow (evalPoly ρ p) k
  | 0     => by simp [polyPow]
  | k + 1 => by simp [polyPow, evalPoly_mul, evalPoly_pow ρ p k]

/-! ### Part 3: Homogenized Rational `letBind` Substitution (`M1-P0 R1` §1.2) -/

def yDeg : Monom → Nat
  | []     => 0
  | e :: _ => e

def tailMonom : Monom → Monom
  | []      => []
  | _ :: es => es

theorem evalMonom_cons_split (val_v : Rat) (ρ : List Rat) (m : Monom) :
    evalMonom (val_v :: ρ) m = ratPow val_v (yDeg m) * evalMonom ρ (tailMonom m) := by
  cases m with
  | nil => simp [yDeg, tailMonom, evalMonom]
  | cons e es => rfl

def maxYDegTerms : List (Monom × Rat) → Nat
  | [] => 0
  | (m, _) :: rest => Nat.max (yDeg m) (maxYDegTerms rest)

theorem yDeg_le_maxYDegTerms {m : Monom} {c : Rat} {ts : List (Monom × Rat)}
    (h : (m, c) ∈ ts) : yDeg m ≤ maxYDegTerms ts := by
  induction ts with
  | nil => contradiction
  | cons hd tl ih =>
      rcases hd with ⟨m', c'⟩
      simp only [List.mem_cons] at h
      cases h with
      | inl heq =>
          injection heq with hm _
          subst hm
          simp [maxYDegTerms, Nat.le_max_left]
      | inr htl =>
          have h1 := ih htl
          simp only [maxYDegTerms]
          exact Nat.le_trans h1 (Nat.le_max_right _ _)

def homogSubstList (D : Nat) (Nv Dv : PolyQ0) : List (Monom × Rat) → PolyQ0
  | [] => PolyQ0.zero
  | (m, c) :: rest =>
      let j := yDeg m
      let baseTerm : PolyQ0 := ⟨canonTerms [(tailMonom m, c)]⟩
      let termPoly := polyMul baseTerm (polyMul (polyPow Nv j) (polyPow Dv (D - j)))
      polyAdd termPoly (homogSubstList D Nv Dv rest)

theorem evalPoly_homogSubstList (ρ : List Rat) (D : Nat) (Nv Dv : PolyQ0) (val_v : Rat)
    (hdv : evalPoly ρ Dv ≠ 0)
    (hval : val_v = evalPoly ρ Nv / evalPoly ρ Dv) :
    ∀ (ts : List (Monom × Rat)),
      (∀ m c, (m, c) ∈ ts → yDeg m ≤ D) →
      evalPoly ρ (homogSubstList D Nv Dv ts) =
        evalTerms (val_v :: ρ) ts * ratPow (evalPoly ρ Dv) D
  | [], _ => by
      simp [homogSubstList, evalTerms, Rat.zero_mul]
  | (m, c) :: rest, hdeg => by
      have hj : yDeg m ≤ D := hdeg m c (by simp)
      have hrest : ∀ m' c', (m', c') ∈ rest → yDeg m' ≤ D :=
        fun m' c' hm => hdeg m' c' (List.mem_cons_of_mem _ hm)
      have ih := evalPoly_homogSubstList ρ D Nv Dv val_v hdv hval rest hrest
      simp only [homogSubstList, evalPoly_add, evalPoly_mul, evalPoly_pow, ih]
      have hbase : evalPoly ρ ⟨canonTerms [(tailMonom m, c)]⟩ = c * evalMonom ρ (tailMonom m) := by
        simp [evalPoly, evalTerms_canonTerms, evalTerms, Rat.add_zero]
      rw [hbase]
      have hnv : evalPoly ρ Nv = val_v * evalPoly ρ Dv := by
        rw [hval]
        exact (rat_div_mul_cancel (evalPoly ρ Nv) (evalPoly ρ Dv) hdv).symm
      have hpow_comb :
          ratPow (evalPoly ρ Nv) (yDeg m) * ratPow (evalPoly ρ Dv) (D - yDeg m) =
            ratPow val_v (yDeg m) * ratPow (evalPoly ρ Dv) D := by
        rw [hnv, ratPow_mul_base, Rat.mul_assoc, ← ratPow_add]
        have hexp : yDeg m + (D - yDeg m) = D := by omega
        rw [hexp]
      rw [hpow_comb, evalTerms, evalMonom_cons_split val_v ρ m]
      grind

/-! ### Part 4: Guard Deduplication & `GPRResultQ0` (`M1-P0 R2/R3`) -/

def dedupGuards : List GuardQ0 → List GuardQ0
  | [] => []
  | g :: gs =>
      let rest := dedupGuards gs
      if g ∈ rest then rest else g :: rest

theorem mem_dedupGuards (ω : GuardQ0) : ∀ (gs : List GuardQ0),
    ω ∈ dedupGuards gs ↔ ω ∈ gs
  | [] => Iff.rfl
  | g :: gs => by
      simp only [dedupGuards]
      split
      · rename_i hmem
        simp only [List.mem_cons]
        constructor
        · intro h; exact Or.inr ((mem_dedupGuards ω gs).mp h)
        · rintro (rfl | h)
          · exact hmem
          · exact (mem_dedupGuards ω gs).mpr h
      · simp only [List.mem_cons, mem_dedupGuards ω gs]

theorem guardsHold_dedupGuards (ρ : List Rat) (gs : List GuardQ0) :
    GuardsHold ρ (dedupGuards gs) ↔ GuardsHold ρ gs := by
  unfold GuardsHold
  constructor
  · intro h ω hω; exact h ω ((mem_dedupGuards ω gs).mpr hω)
  · intro h ω hω; exact h ω ((mem_dedupGuards ω gs).mp hω)

/-- Typed reflection result bundling canonical numerator, denominator, guards, and static unit. -/
structure GPRResultQ0 where
  num    : PolyQ0
  den    : PolyQ0
  guards : List GuardQ0
  unit   : UnitSpecQ0
  deriving DecidableEq, Repr, Inhabited

/-- Reference AST Guarded Polynomial Reflection (`reflectExpr`, `M1-P0 R1/R2/R3`). -/
def reflectExpr (Γ : VarCtxQ0) : ExprQ0 → Option GPRResultQ0
  | .bvar i =>
      match Γ[i]? with
      | some u => some { num := PolyQ0.var i, den := PolyQ0.one, guards := [], unit := u }
      | none   => none
  | .ratLit q u =>
      some { num := PolyQ0.const q, den := PolyQ0.one, guards := [], unit := u }
  | .unaryNeg a =>
      match reflectExpr Γ a with
      | some ra =>
          some { num := polyNeg ra.num, den := ra.den, guards := ra.guards, unit := ra.unit }
      | none => none
  | .binOp op a b =>
      match reflectExpr Γ a, reflectExpr Γ b with
      | some ra, some rb =>
          match synthBinOpUnit op ra.unit rb.unit with
          | none => none
          | some u_out =>
              match op with
              | .add =>
                  some { num := polyAdd (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                         den := polyMul ra.den rb.den
                         guards := dedupGuards (ra.guards ++ rb.guards)
                         unit := u_out }
              | .sub =>
                  some { num := polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                         den := polyMul ra.den rb.den
                         guards := dedupGuards (ra.guards ++ rb.guards)
                         unit := u_out }
              | .mul =>
                  some { num := polyMul ra.num rb.num
                         den := polyMul ra.den rb.den
                         guards := dedupGuards (ra.guards ++ rb.guards)
                         unit := u_out }
              | .div =>
                  some { num := polyMul ra.num rb.den
                         den := polyMul ra.den rb.num
                         guards := dedupGuards (ra.guards ++ rb.guards ++ [.nonZero b])
                         unit := u_out }
      | _, _ => none
  | .letBind v body =>
      match reflectExpr Γ v with
      | none => none
      | some rv =>
          match reflectExpr (rv.unit :: Γ) body with
          | none => none
          | some rb =>
              let dN := maxYDegTerms rb.num.terms
              let dD := maxYDegTerms rb.den.terms
              let nLet := polyMul (polyPow rv.den dD) (homogSubstList dN rv.num rv.den rb.num.terms)
              let dLet := polyMul (polyPow rv.den dN) (homogSubstList dD rv.num rv.den rb.den.terms)
              let gLet := dedupGuards (rv.guards ++ rb.guards.map (substGuard0 v))
              some { num := nLet, den := dLet, guards := gLet, unit := rb.unit }

/-- SSA Wire Guarded Polynomial Reflection (`reflectTape`, `M1-P0 R3` §1.3). -/
def reflectNode {m k : Nat} (Γ : VarCtxQ0) (vt : ValidTape m k)
    (prev : Fin k → Option GPRResultQ0) : ValidNode m k → Option GPRResultQ0
  | .inVar s =>
      match Γ[s.val]? with
      | some u => some { num := PolyQ0.var s.val, den := PolyQ0.one, guards := [], unit := u }
      | none   => none
  | .constRat q u =>
      some { num := PolyQ0.const q, den := PolyQ0.one, guards := [], unit := u }
  | .unaryNeg a =>
      match prev a with
      | some ra =>
          some { num := polyNeg ra.num, den := ra.den, guards := ra.guards, unit := ra.unit }
      | none => none
  | .binOp op a b =>
      match prev a, prev b with
      | some ra, some rb =>
          match synthBinOpUnit op ra.unit rb.unit with
          | none => none
          | some u_out =>
              match op with
              | .add =>
                  some { num := polyAdd (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                         den := polyMul ra.den rb.den
                         guards := dedupGuards (ra.guards ++ rb.guards)
                         unit := u_out }
              | .sub =>
                  some { num := polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                         den := polyMul ra.den rb.den
                         guards := dedupGuards (ra.guards ++ rb.guards)
                         unit := u_out }
              | .mul =>
                  some { num := polyMul ra.num rb.num
                         den := polyMul ra.den rb.den
                         guards := dedupGuards (ra.guards ++ rb.guards)
                         unit := u_out }
              | .div =>
                  some { num := polyMul ra.num rb.den
                         den := polyMul ra.den rb.num
                         guards := dedupGuards (ra.guards ++ rb.guards ++ [.nonZero (reifyTape vt b)])
                         unit := u_out }
      | _, _ => none
  | .strictBind a b =>
      match prev a, prev b with
      | some ra, some rb =>
          some { num := rb.num
                 den := rb.den
                 guards := dedupGuards (ra.guards ++ rb.guards)
                 unit := rb.unit }
      | _, _ => none

def reflectTape {m : Nat} (Γ : VarCtxQ0) :
    {n : Nat} → ValidTape m n → Fin n → Option GPRResultQ0
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i =>
      if h : i.val < k then reflectTape Γ vt ⟨i.val, h⟩
      else reflectNode Γ vt (reflectTape Γ vt) nd

def reflectTapeRoot {m : Nat} (Γ : VarCtxQ0) (rt : RootedTape m) : Option GPRResultQ0 :=
  reflectTape Γ rt.tape rt.root

/-! ### Part 5: `THM-GPR-UNIT-SOUND`, `THM-GPR-TYPED-TOTAL`, `COR-GPR-FAIL-IFF-UNTYPED` (`R3` §2) -/

/-- Target Theorem `THM-GPR-UNIT-SOUND` (Unidirectional Safety Direction, `M1-P0 R3` §2.1):
    Successful AST reflection implies exact static unit agreement AND well-typedness
    of every emitted guard in `r.guards`. -/
theorem thm_gpr_unit_sound :
    ∀ (e : ExprQ0) (Γ : VarCtxQ0) (r : GPRResultQ0),
      reflectExpr Γ e = some r →
      synthUnit Γ e = some r.unit ∧
      (∀ ω ∈ r.guards, (synthUnit Γ (guardExpr ω)).isSome = true)
  | .bvar i, Γ, r, h => by
      simp only [reflectExpr] at h
      cases hget : Γ[i]? with
      | none => rw [hget] at h; contradiction
      | some u =>
        rw [hget] at h
        injection h with hr
        subst hr
        simp [synthUnit, hget]
  | .ratLit q u, Γ, r, h => by
      simp only [reflectExpr] at h
      injection h with hr
      subst hr
      simp [synthUnit]
  | .unaryNeg a, Γ, r, h => by
      simp only [reflectExpr] at h
      cases ha : reflectExpr Γ a with
      | none => rw [ha] at h; contradiction
      | some ra =>
        rw [ha] at h
        injection h with hr
        subst hr
        have iha := thm_gpr_unit_sound a Γ ra ha
        simpa [synthUnit] using iha
  | .binOp op a b, Γ, r, h => by
      simp only [reflectExpr] at h
      cases ha : reflectExpr Γ a with
      | none => rw [ha] at h; contradiction
      | some ra =>
        cases hb : reflectExpr Γ b with
        | none => rw [ha, hb] at h; contradiction
        | some rb =>
          rw [ha, hb] at h
          dsimp only at h
          have iha := thm_gpr_unit_sound a Γ ra ha
          have ihb := thm_gpr_unit_sound b Γ rb hb
          cases hu : synthBinOpUnit op ra.unit rb.unit with
          | none => rw [hu] at h; contradiction
          | some u_out =>
            rw [hu] at h
            dsimp only at h
            cases op <;> (
              injection h with hr
              subst hr
              refine ⟨by simp [synthUnit, iha.1, ihb.1, hu], ?_⟩
              intro ω hω
              rw [mem_dedupGuards] at hω
              simp only [List.mem_append, List.mem_singleton] at hω
              try (rcases hω with h1 | h2; exact iha.2 ω h1; exact ihb.2 ω h2)
              try (rcases hω with (h1 | h2) | rfl
                   · exact iha.2 ω h1
                   · exact ihb.2 ω h2
                   · simp [guardExpr, ihb.1])
            )
  | .letBind v body, Γ, r, h => by
      simp only [reflectExpr] at h
      cases hv : reflectExpr Γ v with
      | none => rw [hv] at h; contradiction
      | some rv =>
        rw [hv] at h
        dsimp only at h
        cases hb : reflectExpr (rv.unit :: Γ) body with
        | none => rw [hb] at h; contradiction
        | some rb =>
          rw [hb] at h
          dsimp only at h
          injection h with hr
          subst hr
          have ihv := thm_gpr_unit_sound v Γ rv hv
          have ihb := thm_gpr_unit_sound body (rv.unit :: Γ) rb hb
          refine ⟨by simp [synthUnit, ihv.1, ihb.1], ?_⟩
          intro ω hω
          rw [mem_dedupGuards, List.mem_append] at hω
          cases hω with
          | inl h1 => exact ihv.2 ω h1
          | inr h2 =>
              rcases List.mem_map.mp h2 with ⟨ω0, hω0, rfl⟩
              rw [lem_substGuardUnit ihv.1 ω0]
              exact ihb.2 ω0 hω0

/-- Target Theorem `THM-GPR-TYPED-TOTAL` (Existential Totality on Well-Typed Q0 Terms, `R3` §2.2). -/
theorem thm_gpr_typed_total :
    ∀ (e : ExprQ0) (Γ : VarCtxQ0) (u : UnitSpecQ0),
      synthUnit Γ e = some u →
      ∃ r : GPRResultQ0, reflectExpr Γ e = some r ∧ r.unit = u
  | .bvar i, Γ, u, h => by
      simp only [synthUnit] at h
      exact ⟨{ num := PolyQ0.var i, den := PolyQ0.one, guards := [], unit := u },
             by simp [reflectExpr, h], rfl⟩
  | .ratLit q u', Γ, u, h => by
      simp only [synthUnit] at h
      injection h with hu
      subst hu
      exact ⟨{ num := PolyQ0.const q, den := PolyQ0.one, guards := [], unit := u' },
             rfl, rfl⟩
  | .unaryNeg a, Γ, u, h => by
      simp only [synthUnit] at h
      rcases thm_gpr_typed_total a Γ u h with ⟨ra, hra, hru⟩
      exact ⟨{ num := polyNeg ra.num, den := ra.den, guards := ra.guards, unit := ra.unit },
             by simp [reflectExpr, hra], hru⟩
  | .binOp op a b, Γ, u, h => by
      simp only [synthUnit] at h
      cases ha : synthUnit Γ a with
      | none => rw [ha] at h; contradiction
      | some u1 =>
        cases hb : synthUnit Γ b with
        | none => rw [ha, hb] at h; contradiction
        | some u2 =>
          rw [ha, hb] at h
          dsimp only at h
          rcases thm_gpr_typed_total a Γ u1 ha with ⟨ra, hra, hrua⟩
          rcases thm_gpr_typed_total b Γ u2 hb with ⟨rb, hrb, hrub⟩
          subst hrua; subst hrub
          cases op with
          | add =>
              exact ⟨{ num := polyAdd (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                       den := polyMul ra.den rb.den
                       guards := dedupGuards (ra.guards ++ rb.guards)
                       unit := u }, by simp [reflectExpr, hra, hrb, h], rfl⟩
          | sub =>
              exact ⟨{ num := polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                       den := polyMul ra.den rb.den
                       guards := dedupGuards (ra.guards ++ rb.guards)
                       unit := u }, by simp [reflectExpr, hra, hrb, h], rfl⟩
          | mul =>
              exact ⟨{ num := polyMul ra.num rb.num
                       den := polyMul ra.den rb.den
                       guards := dedupGuards (ra.guards ++ rb.guards)
                       unit := u }, by simp [reflectExpr, hra, hrb, h], rfl⟩
          | div =>
              exact ⟨{ num := polyMul ra.num rb.den
                       den := polyMul ra.den rb.num
                       guards := dedupGuards (ra.guards ++ rb.guards ++ [.nonZero b])
                       unit := u }, by simp [reflectExpr, hra, hrb, h], rfl⟩
  | .letBind v body, Γ, u, h => by
      simp only [synthUnit] at h
      cases hv : synthUnit Γ v with
      | none => rw [hv] at h; contradiction
      | some uv =>
        rw [hv] at h
        dsimp only at h
        rcases thm_gpr_typed_total v Γ uv hv with ⟨rv, hrv, hruv⟩
        subst hruv
        rcases thm_gpr_typed_total body (rv.unit :: Γ) u h with ⟨rb, hrb, hrub⟩
        let dN := maxYDegTerms rb.num.terms
        let dD := maxYDegTerms rb.den.terms
        exact ⟨{ num := polyMul (polyPow rv.den dD) (homogSubstList dN rv.num rv.den rb.num.terms)
                 den := polyMul (polyPow rv.den dN) (homogSubstList dD rv.num rv.den rb.den.terms)
                 guards := dedupGuards (rv.guards ++ rb.guards.map (substGuard0 v))
                 unit := rb.unit }, by simp [reflectExpr, hrv, hrb, dN, dD], hrub⟩

/-- Target Corollary `COR-GPR-FAIL-IFF-UNTYPED` (`M1-P0 R3` §2.3):
    Reflection failure and static unit failure coincide in `SIR-Core-Q0`. -/
theorem cor_gpr_fail_iff_untyped (Γ : VarCtxQ0) (e : ExprQ0) :
    reflectExpr Γ e = none ↔ synthUnit Γ e = none := by
  constructor
  · intro hnone
    cases hs : synthUnit Γ e with
    | none => rfl
    | some u =>
        rcases thm_gpr_typed_total e Γ u hs with ⟨r, hr, _⟩
        rw [hr] at hnone
        contradiction
  · intro hsnone
    cases hr : reflectExpr Γ e with
    | none => rfl
    | some r =>
        have hs := (thm_gpr_unit_sound e Γ r hr).1
        rw [hsnone] at hs
        contradiction

/-! ### Part 6: `THM-GPR-VALUE-SOUND` & `THM-GPR-DOMAIN-EXACT` on AST (`R2/R3`) -/

/-- Target Theorem `THM-GPR-VALUE-SOUND` (`M1-P0 R2` §3.2 / `R3` §1):
    Whenever environment `ρ` models `Γ` and satisfies all emitted guards `r.guards`,
    the reflected denominator is strictly non-zero and `denoteExpr ρ e` equals `some (N/D)`. -/
theorem thm_gpr_value_sound :
    ∀ (e : ExprQ0) (Γ : VarCtxQ0) (ρ : List Rat) (r : GPRResultQ0),
      EnvModelsCtx ρ Γ →
      reflectExpr Γ e = some r →
      GuardsHold ρ r.guards →
      evalPoly ρ r.den ≠ 0 ∧
      denoteExpr ρ e = some (evalPoly ρ r.num / evalPoly ρ r.den)
  | .bvar i, Γ, ρ, r, henv, hr, _ => by
      simp only [reflectExpr] at hr
      cases hget : Γ[i]? with
      | none => rw [hget] at hr; contradiction
      | some u =>
        rw [hget] at hr
        injection hr with hreq
        subst hreq
        have hi_Γ : i < Γ.length :=
          if hlt : i < Γ.length then hlt
          else False.elim (by
            have hn := List.getElem?_eq_none (Nat.le_of_not_lt hlt)
            rw [hn] at hget; contradiction)
        have hi_ρ : i < ρ.length := by rw [henv]; exact hi_Γ
        refine ⟨by simp, ?_⟩
        simp [denoteExpr, List.getElem?_eq_getElem hi_ρ, evalPoly_var ρ i hi_ρ, rat_div_one]
  | .ratLit q u, _, ρ, r, _, hr, _ => by
      simp only [reflectExpr] at hr
      injection hr with hreq
      subst hreq
      exact ⟨by simp, by simp [denoteExpr, rat_div_one]⟩
  | .unaryNeg a, Γ, ρ, r, henv, hr, hg => by
      simp only [reflectExpr] at hr
      cases ha : reflectExpr Γ a with
      | none => rw [ha] at hr; contradiction
      | some ra =>
        rw [ha] at hr
        injection hr with hreq
        subst hreq
        rcases thm_gpr_value_sound a Γ ρ ra henv ha hg with ⟨hda, hden⟩
        refine ⟨hda, ?_⟩
        simp [denoteExpr, hden, evalPoly_neg, rat_neg_div]
  | .binOp op a b, Γ, ρ, r, henv, hr, hg => by
      simp only [reflectExpr] at hr
      cases ha : reflectExpr Γ a with
      | none => rw [ha] at hr; contradiction
      | some ra =>
        cases hb : reflectExpr Γ b with
        | none => rw [ha, hb] at hr; contradiction
        | some rb =>
          rw [ha, hb] at hr
          dsimp only at hr
          cases hu : synthBinOpUnit op ra.unit rb.unit with
          | none => rw [hu] at hr; contradiction
          | some u_out =>
            rw [hu] at hr
            dsimp only at hr
            cases op with
            | add =>
                injection hr with hreq; subst hreq
                have hg' := (guardsHold_dedupGuards ρ _).mp hg
                rcases guardsHold_append.mp hg' with ⟨hga, hgb⟩
                rcases thm_gpr_value_sound a Γ ρ ra henv ha hga with ⟨hda, hdena⟩
                rcases thm_gpr_value_sound b Γ ρ rb henv hb hgb with ⟨hdb, hdenb⟩
                refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hdb, ?_⟩
                simp [denoteExpr, evalBinOp, hdena, hdenb, evalPoly_add, evalPoly_mul,
                      rat_add_frac _ _ _ _ hda hdb]
            | sub =>
                injection hr with hreq; subst hreq
                have hg' := (guardsHold_dedupGuards ρ _).mp hg
                rcases guardsHold_append.mp hg' with ⟨hga, hgb⟩
                rcases thm_gpr_value_sound a Γ ρ ra henv ha hga with ⟨hda, hdena⟩
                rcases thm_gpr_value_sound b Γ ρ rb henv hb hgb with ⟨hdb, hdenb⟩
                refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hdb, ?_⟩
                simp [denoteExpr, evalBinOp, hdena, hdenb, evalPoly_sub, evalPoly_mul,
                      rat_sub_frac _ _ _ _ hda hdb]
            | mul =>
                injection hr with hreq; subst hreq
                have hg' := (guardsHold_dedupGuards ρ _).mp hg
                rcases guardsHold_append.mp hg' with ⟨hga, hgb⟩
                rcases thm_gpr_value_sound a Γ ρ ra henv ha hga with ⟨hda, hdena⟩
                rcases thm_gpr_value_sound b Γ ρ rb henv hb hgb with ⟨hdb, hdenb⟩
                refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hdb, ?_⟩
                simp [denoteExpr, evalBinOp, hdena, hdenb, evalPoly_mul,
                      rat_mul_frac _ _ _ _ hda hdb]
            | div =>
                injection hr with hreq; subst hreq
                have hg' := (guardsHold_dedupGuards ρ _).mp hg
                rcases guardsHold_append.mp hg' with ⟨hgab, hgnz⟩
                rcases guardsHold_append.mp hgab with ⟨hga, hgb⟩
                rcases thm_gpr_value_sound a Γ ρ ra henv ha hga with ⟨hda, hdena⟩
                rcases thm_gpr_value_sound b Γ ρ rb henv hb hgb with ⟨hdb, hdenb⟩
                have hbz_guard : evalGuard ρ (.nonZero b) = true := hgnz (.nonZero b) (by simp)
                rcases (evalGuard_nonZero_iff ρ b).mp hbz_guard with ⟨vb, hvb_eq, hvb_nz⟩
                rw [hdenb] at hvb_eq
                injection hvb_eq with hfrac_eq
                have hfrac_nz : evalPoly ρ rb.num / evalPoly ρ rb.den ≠ 0 := by
                  rw [hfrac_eq]; exact hvb_nz
                have hnb_nz : evalPoly ρ rb.num ≠ 0 := by
                  intro h0
                  apply hfrac_nz
                  rw [h0]
                  grind
                refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hnb_nz, ?_⟩
                simp [denoteExpr, evalBinOp, hdena, hdenb, hfrac_nz, evalPoly_mul,
                      rat_div_frac _ _ _ _ hda hnb_nz hdb]
  | .letBind v body, Γ, ρ, r, henv, hr, hg => by
      simp only [reflectExpr] at hr
      cases hv : reflectExpr Γ v with
      | none => rw [hv] at hr; contradiction
      | some rv =>
        rw [hv] at hr
        dsimp only at hr
        cases hb : reflectExpr (rv.unit :: Γ) body with
        | none => rw [hb] at hr; contradiction
        | some rb =>
          rw [hb] at hr
          dsimp only at hr
          injection hr with hreq
          subst hreq
          have hg' := (guardsHold_dedupGuards ρ _).mp hg
          rcases guardsHold_append.mp hg' with ⟨hgv, hgb_map⟩
          rcases thm_gpr_value_sound v Γ ρ rv henv hv hgv with ⟨hdv, hdenv⟩
          let val_v := evalPoly ρ rv.num / evalPoly ρ rv.den
          have hgb : GuardsHold (val_v :: ρ) rb.guards :=
            (guardsHold_map_substGuard0 hdenv rb.guards).mp hgb_map
          have henv' : EnvModelsCtx (val_v :: ρ) (rv.unit :: Γ) := by
            simp [EnvModelsCtx] at henv ⊢; exact henv
          rcases thm_gpr_value_sound body (rv.unit :: Γ) (val_v :: ρ) rb henv' hb hgb
            with ⟨hdb, hdenb⟩
          let dN := maxYDegTerms rb.num.terms
          let dD := maxYDegTerms rb.den.terms
          have hsubN := evalPoly_homogSubstList ρ dN rv.num rv.den val_v hdv rfl rb.num.terms
            (fun m c hm => yDeg_le_maxYDegTerms hm)
          have hsubD := evalPoly_homogSubstList ρ dD rv.num rv.den val_v hdv rfl rb.den.terms
            (fun m c hm => yDeg_le_maxYDegTerms hm)
          have hpowN_nz : ratPow (evalPoly ρ rv.den) dN ≠ 0 := ratPow_ne_zero hdv dN
          have hpowD_nz : ratPow (evalPoly ρ rv.den) dD ≠ 0 := ratPow_ne_zero hdv dD
          have hdLet_eq :
              evalPoly ρ (polyMul (polyPow rv.den dN) (homogSubstList dD rv.num rv.den rb.den.terms)) =
                evalPoly (val_v :: ρ) rb.den * (ratPow (evalPoly ρ rv.den) dN * ratPow (evalPoly ρ rv.den) dD) := by
            rw [evalPoly_mul, evalPoly_pow, hsubD]
            change _ * (evalPoly (val_v :: ρ) rb.den * _) = _
            grind
          have hnLet_eq :
              evalPoly ρ (polyMul (polyPow rv.den dD) (homogSubstList dN rv.num rv.den rb.num.terms)) =
                evalPoly (val_v :: ρ) rb.num * (ratPow (evalPoly ρ rv.den) dN * ratPow (evalPoly ρ rv.den) dD) := by
            rw [evalPoly_mul, evalPoly_pow, hsubN]
            change _ * (evalPoly (val_v :: ρ) rb.num * _) = _
            grind
          have hscale_nz : ratPow (evalPoly ρ rv.den) dN * ratPow (evalPoly ρ rv.den) dD ≠ 0 :=
            rat_mul_ne_zero hpowN_nz hpowD_nz
          have hdLet_nz : evalPoly ρ (polyMul (polyPow rv.den dN) (homogSubstList dD rv.num rv.den rb.den.terms)) ≠ 0 := by
            rw [hdLet_eq]
            exact rat_mul_ne_zero hdb hscale_nz
          refine ⟨hdLet_nz, ?_⟩
          simp only [denoteExpr, hdenv]
          rw [hdenb, hnLet_eq, hdLet_eq, rat_scale_frac_right _ _ _ hdb hscale_nz]

/-- Target Lemma `THM-GPR-DOMAIN-EXACT` on AST (`M1-P0 R3` §1.4):
    `GuardsHold ρ r.guards` holds if and only if `denoteExpr ρ e` is defined (`isSome`). -/
theorem thm_gpr_domain_exact :
    ∀ (e : ExprQ0) (Γ : VarCtxQ0) (ρ : List Rat) (r : GPRResultQ0),
      EnvModelsCtx ρ Γ →
      reflectExpr Γ e = some r →
      (GuardsHold ρ r.guards ↔ (denoteExpr ρ e).isSome = true)
  | e, Γ, ρ, r, henv, hr => by
      constructor
      · intro hg
        rcases thm_gpr_value_sound e Γ ρ r henv hr hg with ⟨_, hden⟩
        simp [hden]
      · revert Γ ρ r
        induction e with
        | bvar i =>
            intro Γ ρ r _ hr _
            simp only [reflectExpr] at hr
            cases hget : Γ[i]? with
            | none => rw [hget] at hr; contradiction
            | some u =>
                rw [hget] at hr; injection hr with hreq; subst hreq
                intro _ hmem; simp at hmem
        | ratLit q u =>
            intro Γ ρ r _ hr _
            simp only [reflectExpr] at hr; injection hr with hreq; subst hreq
            intro _ hmem; simp at hmem
        | unaryNeg a iha =>
            intro Γ ρ r henv hr hsome
            simp only [reflectExpr] at hr
            cases ha : reflectExpr Γ a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
                rw [ha] at hr; injection hr with hreq; subst hreq
                have hsome_a : (denoteExpr ρ a).isSome = true := by
                  cases hm : denoteExpr ρ a with
                  | none => simp [denoteExpr, hm] at hsome
                  | some _ => rfl
                exact iha Γ ρ ra henv ha hsome_a
        | binOp op a b iha ihb =>
            intro Γ ρ r henv hr hsome
            simp only [reflectExpr] at hr
            cases ha : reflectExpr Γ a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
              cases hb : reflectExpr Γ b with
              | none => rw [ha, hb] at hr; contradiction
              | some rb =>
                rw [ha, hb] at hr; dsimp only at hr
                cases hu : synthBinOpUnit op ra.unit rb.unit with
                | none => rw [hu] at hr; contradiction
                | some u_out =>
                  rw [hu] at hr; dsimp only at hr
                  cases hda : denoteExpr ρ a with
                  | none => simp [denoteExpr, evalBinOp, hda] at hsome
                  | some va =>
                    cases hdb : denoteExpr ρ b with
                    | none => simp [denoteExpr, evalBinOp, hda, hdb] at hsome
                    | some vb =>
                      have hga := iha Γ ρ ra henv ha (by simp [hda])
                      have hgb := ihb Γ ρ rb henv hb (by simp [hdb])
                      cases op with
                      | add | sub | mul =>
                          injection hr with hreq; subst hreq
                          exact (guardsHold_dedupGuards ρ _).mpr
                            (guardsHold_append.mpr ⟨hga, hgb⟩)
                      | div =>
                          injection hr with hreq; subst hreq
                          have hvb_nz : vb ≠ 0 := by
                            intro h0
                            simp [denoteExpr, evalBinOp, hda, hdb, h0] at hsome
                          have hgnz : GuardsHold ρ [.nonZero b] := by
                            intro ω hω
                            simp only [List.mem_singleton] at hω
                            subst hω
                            exact (evalGuard_nonZero_iff ρ b).mpr ⟨vb, hdb, hvb_nz⟩
                          exact (guardsHold_dedupGuards ρ _).mpr
                            (guardsHold_append.mpr ⟨guardsHold_append.mpr ⟨hga, hgb⟩, hgnz⟩)
        | letBind v body ihv ihb =>
            intro Γ ρ r henv hr hsome
            simp only [reflectExpr] at hr
            cases hv : reflectExpr Γ v with
            | none => rw [hv] at hr; contradiction
            | some rv =>
              rw [hv] at hr; dsimp only at hr
              cases hb : reflectExpr (rv.unit :: Γ) body with
              | none => rw [hb] at hr; contradiction
              | some rb =>
                rw [hb] at hr; dsimp only at hr
                injection hr with hreq; subst hreq
                cases hdv : denoteExpr ρ v with
                | none => simp [denoteExpr, hdv] at hsome
                | some val_v =>
                  have hsome_b : (denoteExpr (val_v :: ρ) body).isSome = true := by
                    simpa [denoteExpr, hdv] using hsome
                  have hgv := ihv Γ ρ rv henv hv (by simp [hdv])
                  have henv' : EnvModelsCtx (val_v :: ρ) (rv.unit :: Γ) := by
                    simp [EnvModelsCtx] at henv ⊢; exact henv
                  have hgb := ihb (rv.unit :: Γ) (val_v :: ρ) rb henv' hb hsome_b
                  have hgb_map := (guardsHold_map_substGuard0 hdv rb.guards).mpr hgb
                  exact (guardsHold_dedupGuards ρ _).mpr (guardsHold_append.mpr ⟨hgv, hgb_map⟩)

/-! ### Part 7: Tape Reflection Soundness, Domain Exactness & Locality (`R3` §1.3 & §3) -/

theorem thm_tape_gpr_unit_sound {m : Nat} (Γ : VarCtxQ0) :
    ∀ {n : Nat} (vt : ValidTape m n) (i : Fin n) (r : GPRResultQ0),
      reflectTape Γ vt i = some r →
      synthUnitTape Γ vt i = some r.unit ∧
      (∀ ω ∈ r.guards, (synthUnit Γ (guardExpr ω)).isSome = true)
  | 0, .empty, i, _, _ => i.elim0
  | k + 1, .snoc vt nd, i, r, hr => by
      simp only [reflectTape, synthUnitTape] at hr ⊢
      split at hr
      · rename_i hlt
        simp only [hlt, dite_true]
        exact thm_tape_gpr_unit_sound Γ vt ⟨i.val, hlt⟩ r hr
      · rename_i hge
        simp only [hge, dite_false]
        cases nd with
        | inVar s =>
            simp only [reflectNode] at hr
            cases hget : Γ[s.val]? with
            | none => rw [hget] at hr; contradiction
            | some u =>
                rw [hget] at hr; injection hr with hreq; subst hreq
                simp [unitNode, hget]
        | constRat q u =>
            simp only [reflectNode] at hr
            injection hr with hreq; subst hreq
            simp [unitNode]
        | unaryNeg a =>
            simp only [reflectNode] at hr
            cases ha : reflectTape Γ vt a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
                rw [ha] at hr; injection hr with hreq; subst hreq
                have iha := thm_tape_gpr_unit_sound Γ vt a ra ha
                simpa [unitNode] using iha
        | binOp op a b =>
            simp only [reflectNode] at hr
            cases ha : reflectTape Γ vt a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
              cases hb : reflectTape Γ vt b with
              | none => rw [ha, hb] at hr; contradiction
              | some rb =>
                rw [ha, hb] at hr; dsimp only at hr
                have iha := thm_tape_gpr_unit_sound Γ vt a ra ha
                have ihb := thm_tape_gpr_unit_sound Γ vt b rb hb
                cases hu : synthBinOpUnit op ra.unit rb.unit with
                | none => rw [hu] at hr; contradiction
                | some u_out =>
                  rw [hu] at hr; dsimp only at hr
                  cases op <;> (
                    injection hr with hreq; subst hreq
                    refine ⟨by simp [unitNode, iha.1, ihb.1, hu], ?_⟩
                    intro ω hω
                    rw [mem_dedupGuards] at hω
                    simp only [List.mem_append, List.mem_singleton] at hω
                    try (rcases hω with h1 | h2; exact iha.2 ω h1; exact ihb.2 ω h2)
                    try (rcases hω with (h1 | h2) | rfl
                         · exact iha.2 ω h1
                         · exact ihb.2 ω h2
                         · simp [guardExpr, (lem_reify_exact vt b).2 Γ, ihb.1])
                  )
        | strictBind a b =>
            simp only [reflectNode] at hr
            cases ha : reflectTape Γ vt a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
              cases hb : reflectTape Γ vt b with
              | none => rw [ha, hb] at hr; contradiction
              | some rb =>
                rw [ha, hb] at hr; dsimp only at hr
                injection hr with hreq; subst hreq
                have iha := thm_tape_gpr_unit_sound Γ vt a ra ha
                have ihb := thm_tape_gpr_unit_sound Γ vt b rb hb
                refine ⟨by simp [unitNode, iha.1, ihb.1], ?_⟩
                intro ω hω
                rw [mem_dedupGuards, List.mem_append] at hω
                cases hω with
                | inl h1 => exact iha.2 ω h1
                | inr h2 => exact ihb.2 ω h2

theorem thm_tape_gpr_typed_total {m : Nat} (Γ : VarCtxQ0) :
    ∀ {n : Nat} (vt : ValidTape m n) (i : Fin n) (u : UnitSpecQ0),
      synthUnitTape Γ vt i = some u →
      ∃ r : GPRResultQ0, reflectTape Γ vt i = some r ∧ r.unit = u
  | 0, .empty, i, _, _ => i.elim0
  | k + 1, .snoc vt nd, i, u, hs => by
      simp only [synthUnitTape, reflectTape] at hs ⊢
      split at hs
      · rename_i hlt
        simp only [hlt, dite_true]
        exact thm_tape_gpr_typed_total Γ vt ⟨i.val, hlt⟩ u hs
      · rename_i hge
        simp only [hge, dite_false]
        cases nd with
        | inVar s =>
            simp only [unitNode] at hs
            exact ⟨{ num := PolyQ0.var s.val, den := PolyQ0.one, guards := [], unit := u },
                   by simp [reflectNode, hs], rfl⟩
        | constRat q u' =>
            simp only [unitNode] at hs
            injection hs with hu; subst hu
            exact ⟨{ num := PolyQ0.const q, den := PolyQ0.one, guards := [], unit := u' },
                   rfl, rfl⟩
        | unaryNeg a =>
            simp only [unitNode] at hs
            rcases thm_tape_gpr_typed_total Γ vt a u hs with ⟨ra, hra, hrua⟩
            exact ⟨{ num := polyNeg ra.num, den := ra.den, guards := ra.guards, unit := ra.unit },
                   by simp [reflectNode, hra], hrua⟩
        | binOp op a b =>
            simp only [unitNode] at hs
            cases ha : synthUnitTape Γ vt a with
            | none => rw [ha] at hs; contradiction
            | some u1 =>
              cases hb : synthUnitTape Γ vt b with
              | none => rw [ha, hb] at hs; contradiction
              | some u2 =>
                rw [ha, hb] at hs; dsimp only at hs
                rcases thm_tape_gpr_typed_total Γ vt a u1 ha with ⟨ra, hra, hrua⟩
                rcases thm_tape_gpr_typed_total Γ vt b u2 hb with ⟨rb, hrb, hrub⟩
                subst hrua; subst hrub
                cases op with
                | add =>
                    exact ⟨{ num := polyAdd (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                             den := polyMul ra.den rb.den
                             guards := dedupGuards (ra.guards ++ rb.guards)
                             unit := u }, by simp [reflectNode, hra, hrb, hs], rfl⟩
                | sub =>
                    exact ⟨{ num := polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)
                             den := polyMul ra.den rb.den
                             guards := dedupGuards (ra.guards ++ rb.guards)
                             unit := u }, by simp [reflectNode, hra, hrb, hs], rfl⟩
                | mul =>
                    exact ⟨{ num := polyMul ra.num rb.num
                             den := polyMul ra.den rb.den
                             guards := dedupGuards (ra.guards ++ rb.guards)
                             unit := u }, by simp [reflectNode, hra, hrb, hs], rfl⟩
                | div =>
                    exact ⟨{ num := polyMul ra.num rb.den
                             den := polyMul ra.den rb.num
                             guards := dedupGuards (ra.guards ++ rb.guards ++ [.nonZero (reifyTape vt b)])
                             unit := u }, by simp [reflectNode, hra, hrb, hs], rfl⟩
        | strictBind a b =>
            simp only [unitNode] at hs
            cases ha : synthUnitTape Γ vt a with
            | none => rw [ha] at hs; contradiction
            | some u1 =>
              cases hb : synthUnitTape Γ vt b with
              | none => rw [ha, hb] at hs; contradiction
              | some u2 =>
                rw [ha, hb] at hs; dsimp only at hs
                injection hs with hu; subst hu
                rcases thm_tape_gpr_typed_total Γ vt a u1 ha with ⟨ra, hra, _⟩
                rcases thm_tape_gpr_typed_total Γ vt b u2 hb with ⟨rb, hrb, hrub⟩
                exact ⟨{ num := rb.num, den := rb.den,
                         guards := dedupGuards (ra.guards ++ rb.guards), unit := rb.unit },
                       by simp [reflectNode, hra, hrb], hrub⟩

theorem cor_tape_gpr_fail_iff_untyped {m n : Nat} (Γ : VarCtxQ0)
    (vt : ValidTape m n) (i : Fin n) :
    reflectTape Γ vt i = none ↔ synthUnitTape Γ vt i = none := by
  constructor
  · intro hnone
    cases hs : synthUnitTape Γ vt i with
    | none => rfl
    | some u =>
        rcases thm_tape_gpr_typed_total Γ vt i u hs with ⟨r, hr, _⟩
        rw [hr] at hnone; contradiction
  · intro hsnone
    cases hr : reflectTape Γ vt i with
    | none => rfl
    | some r =>
        have hs := (thm_tape_gpr_unit_sound Γ vt i r hr).1
        rw [hsnone] at hs; contradiction

/-- Target Theorem `THM-TAPE-GPR-VALUE-SOUND` (`M1-P0 R3` §1.3):
    Value soundness of `reflectTape` on ANY `ValidTape m n` (including `strictBind`). -/
theorem thm_tape_gpr_value_sound {m : Nat} (Γ : VarCtxQ0) (ρ : List Rat)
    (henv : EnvModelsCtx ρ Γ) :
    ∀ {n : Nat} (vt : ValidTape m n) (i : Fin n) (r : GPRResultQ0),
      reflectTape Γ vt i = some r →
      GuardsHold ρ r.guards →
      evalPoly ρ r.den ≠ 0 ∧
      evalValidTape ρ vt i = some (evalPoly ρ r.num / evalPoly ρ r.den)
  | 0, .empty, i, _, _, _ => i.elim0
  | k + 1, .snoc vt nd, i, r, hr, hg => by
      simp only [reflectTape, evalValidTape] at hr ⊢
      split at hr
      · rename_i hlt
        simp only [hlt, dite_true]
        exact thm_tape_gpr_value_sound Γ ρ henv vt ⟨i.val, hlt⟩ r hr hg
      · rename_i hge
        simp only [hge, dite_false]
        cases nd with
        | inVar s =>
            simp only [reflectNode] at hr
            cases hget : Γ[s.val]? with
            | none => rw [hget] at hr; contradiction
            | some u =>
                rw [hget] at hr; injection hr with hreq; subst hreq
                have hs_Γ : s.val < Γ.length :=
                  if hlt : s.val < Γ.length then hlt
                  else False.elim (by
                    have hn := List.getElem?_eq_none (Nat.le_of_not_lt hlt)
                    rw [hn] at hget; contradiction)
                have hs_ρ : s.val < ρ.length := by rw [henv]; exact hs_Γ
                refine ⟨by simp, ?_⟩
                simp [evalNode, List.getElem?_eq_getElem hs_ρ, evalPoly_var ρ s.val hs_ρ, rat_div_one]
        | constRat q u =>
            simp only [reflectNode] at hr
            injection hr with hreq; subst hreq
            exact ⟨by simp, by simp [evalNode, rat_div_one]⟩
        | unaryNeg a =>
            simp only [reflectNode] at hr
            cases ha : reflectTape Γ vt a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
                rw [ha] at hr; injection hr with hreq; subst hreq
                rcases thm_tape_gpr_value_sound Γ ρ henv vt a ra ha hg with ⟨hda, hdena⟩
                refine ⟨hda, ?_⟩
                simp [evalNode, hdena, evalPoly_neg, rat_neg_div]
        | binOp op a b =>
            simp only [reflectNode] at hr
            cases ha : reflectTape Γ vt a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
              cases hb : reflectTape Γ vt b with
              | none => rw [ha, hb] at hr; contradiction
              | some rb =>
                rw [ha, hb] at hr; dsimp only at hr
                cases hu : synthBinOpUnit op ra.unit rb.unit with
                | none => rw [hu] at hr; contradiction
                | some u_out =>
                  rw [hu] at hr; dsimp only at hr
                  cases op with
                  | add =>
                      injection hr with hreq; subst hreq
                      have hg' := (guardsHold_dedupGuards ρ _).mp hg
                      rcases guardsHold_append.mp hg' with ⟨hga, hgb⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt a ra ha hga with ⟨hda, hdena⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt b rb hb hgb with ⟨hdb, hdenb⟩
                      refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hdb, ?_⟩
                      simp [evalNode, evalBinOp, hdena, hdenb, evalPoly_add, evalPoly_mul,
                            rat_add_frac _ _ _ _ hda hdb]
                  | sub =>
                      injection hr with hreq; subst hreq
                      have hg' := (guardsHold_dedupGuards ρ _).mp hg
                      rcases guardsHold_append.mp hg' with ⟨hga, hgb⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt a ra ha hga with ⟨hda, hdena⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt b rb hb hgb with ⟨hdb, hdenb⟩
                      refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hdb, ?_⟩
                      simp [evalNode, evalBinOp, hdena, hdenb, evalPoly_sub, evalPoly_mul,
                            rat_sub_frac _ _ _ _ hda hdb]
                  | mul =>
                      injection hr with hreq; subst hreq
                      have hg' := (guardsHold_dedupGuards ρ _).mp hg
                      rcases guardsHold_append.mp hg' with ⟨hga, hgb⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt a ra ha hga with ⟨hda, hdena⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt b rb hb hgb with ⟨hdb, hdenb⟩
                      refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hdb, ?_⟩
                      simp [evalNode, evalBinOp, hdena, hdenb, evalPoly_mul,
                            rat_mul_frac _ _ _ _ hda hdb]
                  | div =>
                      injection hr with hreq; subst hreq
                      have hg' := (guardsHold_dedupGuards ρ _).mp hg
                      rcases guardsHold_append.mp hg' with ⟨hgab, hgnz⟩
                      rcases guardsHold_append.mp hgab with ⟨hga, hgb⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt a ra ha hga with ⟨hda, hdena⟩
                      rcases thm_tape_gpr_value_sound Γ ρ henv vt b rb hb hgb with ⟨hdb, hdenb⟩
                      have hbz_guard : evalGuard ρ (.nonZero (reifyTape vt b)) = true :=
                        hgnz (.nonZero (reifyTape vt b)) (by simp)
                      rcases (evalGuard_nonZero_iff ρ (reifyTape vt b)).mp hbz_guard
                        with ⟨vb, hvb_eq, hvb_nz⟩
                      rw [(lem_reify_exact vt b).1 ρ, hdenb] at hvb_eq
                      injection hvb_eq with hfrac_eq
                      have hfrac_nz : evalPoly ρ rb.num / evalPoly ρ rb.den ≠ 0 := by
                        rw [hfrac_eq]; exact hvb_nz
                      have hnb_nz : evalPoly ρ rb.num ≠ 0 := by
                        intro h0; apply hfrac_nz; rw [h0]; grind
                      refine ⟨by rw [evalPoly_mul]; exact rat_mul_ne_zero hda hnb_nz, ?_⟩
                      simp [evalNode, evalBinOp, hdena, hdenb, hfrac_nz, evalPoly_mul,
                            rat_div_frac _ _ _ _ hda hnb_nz hdb]
        | strictBind a b =>
            simp only [reflectNode] at hr
            cases ha : reflectTape Γ vt a with
            | none => rw [ha] at hr; contradiction
            | some ra =>
              cases hb : reflectTape Γ vt b with
              | none => rw [ha, hb] at hr; contradiction
              | some rb =>
                rw [ha, hb] at hr; dsimp only at hr
                injection hr with hreq; subst hreq
                have hg' := (guardsHold_dedupGuards ρ _).mp hg
                rcases guardsHold_append.mp hg' with ⟨hga, hgb⟩
                rcases thm_tape_gpr_value_sound Γ ρ henv vt a ra ha hga with ⟨_, hdena⟩
                rcases thm_tape_gpr_value_sound Γ ρ henv vt b rb hb hgb with ⟨hdb, hdenb⟩
                refine ⟨hdb, ?_⟩
                simp [evalNode, hdena, hdenb]

theorem thm_tape_gpr_domain_exact {m : Nat} (Γ : VarCtxQ0) (ρ : List Rat)
    (henv : EnvModelsCtx ρ Γ) :
    ∀ {n : Nat} (vt : ValidTape m n) (i : Fin n) (r : GPRResultQ0),
      reflectTape Γ vt i = some r →
      (GuardsHold ρ r.guards ↔ (evalValidTape ρ vt i).isSome = true)
  | 0, .empty, i, _, _ => i.elim0
  | k + 1, .snoc vt nd, i, r, hr => by
      constructor
      · intro hg
        rcases thm_tape_gpr_value_sound Γ ρ henv (vt.snoc nd) i r hr hg with ⟨_, hden⟩
        simp [hden]
      · intro hsome
        simp only [reflectTape, evalValidTape] at hr hsome
        split at hr
        · rename_i hlt
          simp only [hlt, dite_true] at hsome
          exact (thm_tape_gpr_domain_exact Γ ρ henv vt ⟨i.val, hlt⟩ r hr).mpr hsome
        · rename_i hge
          simp only [hge, dite_false] at hsome
          cases nd with
          | inVar s =>
              simp only [reflectNode] at hr
              cases hget : Γ[s.val]? with
              | none => rw [hget] at hr; contradiction
              | some u =>
                  rw [hget] at hr; injection hr with hreq; subst hreq
                  intro _ hm; simp at hm
          | constRat q u =>
              simp only [reflectNode] at hr; injection hr with hreq; subst hreq
              intro _ hm; simp at hm
          | unaryNeg a =>
              simp only [reflectNode] at hr
              cases ha : reflectTape Γ vt a with
              | none => rw [ha] at hr; contradiction
              | some ra =>
                  rw [ha] at hr; injection hr with hreq; subst hreq
                  have hsa : (evalValidTape ρ vt a).isSome = true := by
                    cases hm : evalValidTape ρ vt a with
                    | none => simp [evalNode, hm] at hsome
                    | some _ => rfl
                  exact (thm_tape_gpr_domain_exact Γ ρ henv vt a ra ha).mpr hsa
          | binOp op a b =>
              simp only [reflectNode] at hr
              cases ha : reflectTape Γ vt a with
              | none => rw [ha] at hr; contradiction
              | some ra =>
                cases hb : reflectTape Γ vt b with
                | none => rw [ha, hb] at hr; contradiction
                | some rb =>
                  rw [ha, hb] at hr; dsimp only at hr
                  cases hu : synthBinOpUnit op ra.unit rb.unit with
                  | none => rw [hu] at hr; contradiction
                  | some u_out =>
                    rw [hu] at hr; dsimp only at hr
                    cases hda : evalValidTape ρ vt a with
                    | none => simp [evalNode, evalBinOp, hda] at hsome
                    | some va =>
                      cases hdb : evalValidTape ρ vt b with
                      | none => simp [evalNode, evalBinOp, hda, hdb] at hsome
                      | some vb =>
                        have hga := (thm_tape_gpr_domain_exact Γ ρ henv vt a ra ha).mpr (by simp [hda])
                        have hgb := (thm_tape_gpr_domain_exact Γ ρ henv vt b rb hb).mpr (by simp [hdb])
                        cases op with
                        | add | sub | mul =>
                            injection hr with hreq; subst hreq
                            exact (guardsHold_dedupGuards ρ _).mpr
                              (guardsHold_append.mpr ⟨hga, hgb⟩)
                        | div =>
                            injection hr with hreq; subst hreq
                            have hvb_nz : vb ≠ 0 := by
                              intro h0
                              simp [evalNode, evalBinOp, hda, hdb, h0] at hsome
                            have hgnz : GuardsHold ρ [.nonZero (reifyTape vt b)] := by
                              intro ω hω
                              simp only [List.mem_singleton] at hω; subst hω
                              apply (evalGuard_nonZero_iff ρ (reifyTape vt b)).mpr
                              exact ⟨vb, by rw [(lem_reify_exact vt b).1 ρ, hdb], hvb_nz⟩
                            exact (guardsHold_dedupGuards ρ _).mpr
                              (guardsHold_append.mpr ⟨guardsHold_append.mpr ⟨hga, hgb⟩, hgnz⟩)
          | strictBind a b =>
              simp only [reflectNode] at hr
              cases ha : reflectTape Γ vt a with
              | none => rw [ha] at hr; contradiction
              | some ra =>
                cases hb : reflectTape Γ vt b with
                | none => rw [ha, hb] at hr; contradiction
                | some rb =>
                  rw [ha, hb] at hr; dsimp only at hr
                  injection hr with hreq; subst hreq
                  cases hda : evalValidTape ρ vt a with
                  | none => simp [evalNode, hda] at hsome
                  | some _ =>
                    cases hdb : evalValidTape ρ vt b with
                    | none => simp [evalNode, hda, hdb] at hsome
                    | some _ =>
                      have hga := (thm_tape_gpr_domain_exact Γ ρ henv vt a ra ha).mpr (by simp [hda])
                      have hgb := (thm_tape_gpr_domain_exact Γ ρ henv vt b rb hb).mpr (by simp [hdb])
                      exact (guardsHold_dedupGuards ρ _).mpr (guardsHold_append.mpr ⟨hga, hgb⟩)

/-- Dead-row locality extended to `reflectTape` (`M1-P0 R3` §3):
    Unreferenced dead rows outside `r.val :: strictDeps vt₁ r` have zero effect on `reflectTape`! -/
theorem po_tape_locality_reflect {m : Nat} (Γ : VarCtxQ0) :
    ∀ {n : Nat} (vt₁ vt₂ : ValidTape m n) (r : Fin n),
      (∀ j : Fin n, j.val ∈ r.val :: strictDeps vt₁ r → nodeAt vt₁ j = nodeAt vt₂ j) →
      reflectTape Γ vt₁ r = reflectTape Γ vt₂ r
  | 0, .empty, .empty, r, _ => r.elim0
  | k + 1, .snoc u₁ nd₁, .snoc u₂ nd₂, r, hcone => by
      if hlt : r.val < k then
        let r' : Fin k := ⟨r.val, hlt⟩
        have hsub : ∀ j : Fin k, j.val ∈ r'.val :: strictDeps u₁ r' →
            nodeAt u₁ j = nodeAt u₂ j := by
          intro j hj
          have hj' : (Fin.castSucc j).val ∈ r.val :: strictDeps (u₁.snoc nd₁) r := by
            simpa [strictDeps, hlt, r'] using hj
          have hraw := hcone (Fin.castSucc j) hj'
          simpa [nodeAt, j.isLt] using hraw
        simp only [reflectTape, hlt, dite_true]
        exact po_tape_locality_reflect Γ u₁ u₂ r' hsub
      else
        have hr_eq : r = Fin.last k := by
          apply Fin.ext
          have hr_lt := r.isLt
          simp only [Fin.val_last]
          omega
        subst hr_eq
        have htop := hcone (Fin.last k) (by simp)
        simp only [nodeAt_snoc_last] at htop
        have hnd : nd₁ = nd₂ := ValidNode.toRaw_inj htop
        subst hnd
        simp only [reflectTape, Fin.val_last, Nat.lt_irrefl, dite_false]
        have sub_cone : ∀ a : Fin k,
            (∀ x ∈ a.val :: strictDeps u₁ a, x ∈ (Fin.last k).val :: depsNode (strictDeps u₁) nd₁) →
            reflectTape Γ u₁ a = reflectTape Γ u₂ a ∧ reifyTape u₁ a = reifyTape u₂ a := by
          intro a hmem
          have hsub : ∀ j : Fin k, j.val ∈ a.val :: strictDeps u₁ a →
              nodeAt u₁ j = nodeAt u₂ j := by
            intro j hj
            have hj_in := hmem j.val hj
            have hraw := hcone (Fin.castSucc j) (by simpa [strictDeps] using hj_in)
            simpa [nodeAt, j.isLt] using hraw
          exact ⟨po_tape_locality_reflect Γ u₁ u₂ a hsub,
                 (po_tape_locality u₁ u₂ a hsub).2.1⟩
        cases nd₁ with
        | inVar s => simp [reflectNode]
        | constRat q u => simp [reflectNode]
        | unaryNeg a =>
            have iha := sub_cone a (by
              intro x hx; simp only [depsNode, List.mem_cons] at hx ⊢; exact Or.inr hx)
            simp [reflectNode, iha.1]
        | binOp op a b =>
            have iha := sub_cone a (by
              intro x hx; simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxa
              · exact Or.inr (Or.inl rfl)
              · exact Or.inr (Or.inr (Or.inr (Or.inl hxa))))
            have ihb := sub_cone b (by
              intro x hx; simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxb
              · exact Or.inr (Or.inr (Or.inl rfl))
              · exact Or.inr (Or.inr (Or.inr (Or.inr hxb))))
            simp [reflectNode, iha.1, ihb.1, ihb.2]
        | strictBind a b =>
            have iha := sub_cone a (by
              intro x hx; simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxa
              · exact Or.inr (Or.inl rfl)
              · exact Or.inr (Or.inr (Or.inr (Or.inl hxa))))
            have ihb := sub_cone b (by
              intro x hx; simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxb
              · exact Or.inr (Or.inr (Or.inl rfl))
              · exact Or.inr (Or.inr (Or.inr (Or.inr hxb))))
            simp [reflectNode, iha.1, ihb.1]

/-! ### Part 8: Semantic Reflection Equivalence (`≃_Γ`) & Commutation Theorem (`R3` §1.4) -/

/-- Semantic equivalence of two GPR reflection results under context `Γ` (`M1-P0 R3` §1.4). -/
def GPREquiv (Γ : VarCtxQ0) (r1 r2 : GPRResultQ0) : Prop :=
  r1.unit = r2.unit ∧
  (∀ ρ : List Rat, EnvModelsCtx ρ Γ →
    (GuardsHold ρ r1.guards ↔ GuardsHold ρ r2.guards)) ∧
  (∀ ρ : List Rat, EnvModelsCtx ρ Γ → GuardsHold ρ r1.guards →
    evalPoly ρ r1.den ≠ 0 ∧
    evalPoly ρ r2.den ≠ 0 ∧
    evalPoly ρ r1.num / evalPoly ρ r1.den = evalPoly ρ r2.num / evalPoly ρ r2.den)

/-- Lift `GPREquiv` to `Option GPRResultQ0`. -/
def optGPREquiv (Γ : VarCtxQ0) : Option GPRResultQ0 → Option GPRResultQ0 → Prop
  | none,    none    => True
  | some r1, some r2 => GPREquiv Γ r1 r2
  | _,       _       => False

/-- Crown-Jewel Commutation Theorem `THM-AST-TAPE-GPR-COMMUTE` (`M1-P0 R3` §1.4):
    `AST → ValidTape → GPR` commutes simultaneously across partial values (`Option Rat`),
    static physical units (`Option UnitSpecQ0`), and guarded rational reflection (`optGPREquiv`). -/
theorem thm_ast_tape_gpr_commute {m : Nat} (Γ : VarCtxQ0) (hΓ : Γ.length = m)
    (e : ScopedExpr m) :
    (∀ ρ : List Rat, EnvModelsCtx ρ Γ →
      evalTapeRoot ρ (lowerExprTop m e) = denoteExpr ρ e.val) ∧
    (synthUnitTapeRoot Γ (lowerExprTop m e) = synthUnit Γ e.val) ∧
    optGPREquiv Γ (reflectTapeRoot Γ (lowerExprTop m e)) (reflectExpr Γ e.val) := by
  have heq := po_tape_equiv e
  have hval : ∀ ρ : List Rat, EnvModelsCtx ρ Γ →
      evalTapeRoot ρ (lowerExprTop m e) = denoteExpr ρ e.val := by
    intro ρ hρ
    exact heq.1 ρ (hρ.trans hΓ)
  have hunit : synthUnitTapeRoot Γ (lowerExprTop m e) = synthUnit Γ e.val :=
    heq.2 Γ hΓ
  refine ⟨hval, hunit, ?_⟩
  let rt := lowerExprTop m e
  cases hs : synthUnit Γ e.val with
  | none =>
      have hst : synthUnitTape Γ rt.tape rt.root = none := by
        simpa [synthUnitTapeRoot, rt, hs] using hunit
      have hre : reflectExpr Γ e.val = none :=
        (cor_gpr_fail_iff_untyped Γ e.val).mpr hs
      have hrt : reflectTapeRoot Γ rt = none := by
        unfold reflectTapeRoot
        exact (cor_tape_gpr_fail_iff_untyped Γ rt.tape rt.root).mpr hst
      simp [optGPREquiv, rt, hre, hrt]
  | some u =>
      have hst : synthUnitTape Γ rt.tape rt.root = some u := by
        simpa [synthUnitTapeRoot, rt, hs] using hunit
      rcases thm_gpr_typed_total e.val Γ u hs with ⟨re, hre, hrue⟩
      rcases thm_tape_gpr_typed_total Γ rt.tape rt.root u hst with ⟨rt_res, hrt, hrut⟩
      have hrt_root : reflectTapeRoot Γ rt = some rt_res := hrt
      simp only [rt] at hrt_root ⊢
      rw [hrt_root, hre]
      unfold optGPREquiv GPREquiv
      refine ⟨hrut.trans hrue.symm, ?_, ?_⟩
      · intro ρ hρ
        have dom_t := thm_tape_gpr_domain_exact Γ ρ hρ rt.tape rt.root rt_res hrt
        have dom_e := thm_gpr_domain_exact e.val Γ ρ re hρ hre
        have heval := hval ρ hρ
        unfold evalTapeRoot at heval
        rw [dom_t, dom_e, heval]
      · intro ρ hρ hgt
        have dom_t := thm_tape_gpr_domain_exact Γ ρ hρ rt.tape rt.root rt_res hrt
        have dom_e := thm_gpr_domain_exact e.val Γ ρ re hρ hre
        have heval := hval ρ hρ
        unfold evalTapeRoot at heval
        have hge : GuardsHold ρ re.guards := by
          rw [dom_e, ← heval, ← dom_t]; exact hgt
        rcases thm_tape_gpr_value_sound Γ ρ hρ rt.tape rt.root rt_res hrt hgt with ⟨hdt, hdent⟩
        rcases thm_gpr_value_sound e.val Γ ρ re hρ hre hge with ⟨hde, hdene⟩
        rw [hdent, hdene] at heval
        injection heval with hfrac
        exact ⟨hdt, hde, hfrac⟩

end GrandZero.StageA

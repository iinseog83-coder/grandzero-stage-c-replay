/-
  GRANDZERO Ω — Stage A (M1-P0 R3) Isolated Kernel
  Module A-2: Q0PartialSemantics.lean
  Scope: Strict `Option Rat` Partial Semantics, Definedness-Preserving `evalGuard`
         (`none ↦ false`), Unpacked Environment Predicates (`EnvModelsCtx`, `HypsHold`,
         `GuardsHold`), `StrongEq`, and `LEM-SubstDenote`.
-/

import StageA.Q0SyntaxAndUnits

namespace GrandZero.StageA

/-- Strict binary partial arithmetic over `Option Rat`. Division by zero yields `none`. -/
def evalBinOp (op : BinOpQ0) (oa ob : Option Rat) : Option Rat :=
  match oa, ob with
  | some va, some vb =>
      match op with
      | .add => some (va + vb)
      | .sub => some (va - vb)
      | .mul => some (va * vb)
      | .div => if vb = 0 then none else some (va / vb)
  | _, _ => none

/-- Strict partial denotational semantics for `ExprQ0` under value environment `ρ`. -/
def denoteExpr (ρ : List Rat) : ExprQ0 → Option Rat
  | .bvar i => ρ[i]?
  | .ratLit q _ => some q
  | .unaryNeg a =>
      match denoteExpr ρ a with
      | some va => some (-va)
      | none => none
  | .binOp op a b => evalBinOp op (denoteExpr ρ a) (denoteExpr ρ b)
  | .letBind v body =>
      match denoteExpr ρ v with
      | some val_v => denoteExpr (val_v :: ρ) body
      | none => none

/-- Definedness-entailing guard semantics (`M1-P0 R1` §1.1):
    `none` ALWAYS maps to `false`, blocking nested-division traps like `1 / (x / x)` at `x = 0`. -/
def evalGuard (ρ : List Rat) : GuardQ0 → Bool
  | .nonZero d =>
      match denoteExpr ρ d with
      | some v => decide (v ≠ 0)
      | none   => false
  | .pos d =>
      match denoteExpr ρ d with
      | some v => decide (0 < v)
      | none   => false
  | .nonNeg d =>
      match denoteExpr ρ d with
      | some v => decide (0 ≤ v)
      | none   => false

/-- Proposition evaluation (`some true` iff both sides are defined and equal). -/
def denoteProp (ρ : List Rat) : PropQ0 → Option Bool
  | .eqProp a b =>
      match denoteExpr ρ a, denoteExpr ρ b with
      | some va, some vb => some (decide (va = vb))
      | _, _ => none

/-- Strong partial equality (`StrongEq`): both sides must evaluate to `some v` for the same `v`. -/
def StrongEq (ρ : List Rat) (a b : ExprQ0) : Prop :=
  ∃ v : Rat, denoteExpr ρ a = some v ∧ denoteExpr ρ b = some v

/-- Computable boolean test for `StrongEq`. -/
def strongEqBool (ρ : List Rat) (a b : ExprQ0) : Bool :=
  match denoteExpr ρ a, denoteExpr ρ b with
  | some va, some vb => decide (va = vb)
  | _, _ => false

theorem strongEqBool_iff (ρ : List Rat) (a b : ExprQ0) :
    strongEqBool ρ a b = true ↔ StrongEq ρ a b := by
  unfold strongEqBool StrongEq
  cases ha : denoteExpr ρ a with
  | none =>
      simp
  | some va =>
    cases hb : denoteExpr ρ b with
    | none =>
        simp
    | some vb =>
        simp only [decide_eq_true_eq]
        constructor
        · intro h
          subst h
          exact ⟨va, rfl, rfl⟩
        · rintro ⟨v, h1, h2⟩
          injection h1 with h1'
          injection h2 with h2'
          exact h1'.trans h2'.symm

theorem StrongEq.refl_of_isSome {ρ : List Rat} {a : ExprQ0}
    (h : (denoteExpr ρ a).isSome = true) : StrongEq ρ a a := by
  cases ha : denoteExpr ρ a with
  | none => rw [ha] at h; contradiction
  | some va => exact ⟨va, ha, ha⟩

theorem StrongEq.symm {ρ : List Rat} {a b : ExprQ0} (h : StrongEq ρ a b) :
    StrongEq ρ b a := by
  rcases h with ⟨v, ha, hb⟩
  exact ⟨v, hb, ha⟩

theorem StrongEq.trans {ρ : List Rat} {a b c : ExprQ0}
    (h1 : StrongEq ρ a b) (h2 : StrongEq ρ b c) : StrongEq ρ a c := by
  rcases h1 with ⟨v1, ha, hb1⟩
  rcases h2 with ⟨v2, hb2, hc⟩
  rw [hb1] at hb2
  injection hb2 with hv
  subst hv
  exact ⟨v1, ha, hc⟩

/-! ### Unpacked Three-Part Environment Predicates (`M1-P0 R1` §3.1) -/

def EnvModelsCtx (ρ : List Rat) (Γ : VarCtxQ0) : Prop :=
  ρ.length = Γ.length

def envModelsCtxBool (ρ : List Rat) (Γ : VarCtxQ0) : Bool :=
  decide (ρ.length = Γ.length)

theorem envModelsCtxBool_iff (ρ : List Rat) (Γ : VarCtxQ0) :
    envModelsCtxBool ρ Γ = true ↔ EnvModelsCtx ρ Γ := by
  simp [envModelsCtxBool, EnvModelsCtx]

def HypsHold (ρ : List Rat) (H : HypCtxQ0) : Prop :=
  ∀ ψ ∈ H, denoteProp ρ ψ = some true

def hypsHoldBool (ρ : List Rat) (H : HypCtxQ0) : Bool :=
  H.all (fun ψ => denoteProp ρ ψ == some true)

theorem hypsHoldBool_iff (ρ : List Rat) (H : HypCtxQ0) :
    hypsHoldBool ρ H = true ↔ HypsHold ρ H := by
  simp [hypsHoldBool, HypsHold]

def GuardsHold (ρ : List Rat) (Ω : List GuardQ0) : Prop :=
  ∀ ω ∈ Ω, evalGuard ρ ω = true

def guardsHoldBool (ρ : List Rat) (Ω : List GuardQ0) : Bool :=
  Ω.all (fun ω => evalGuard ρ ω)

theorem guardsHoldBool_iff (ρ : List Rat) (Ω : List GuardQ0) :
    guardsHoldBool ρ Ω = true ↔ GuardsHold ρ Ω := by
  simp [guardsHoldBool, GuardsHold]

theorem guardsHold_append {ρ : List Rat} {Ω₁ Ω₂ : List GuardQ0} :
    GuardsHold ρ (Ω₁ ++ Ω₂) ↔ GuardsHold ρ Ω₁ ∧ GuardsHold ρ Ω₂ := by
  unfold GuardsHold
  constructor
  · intro h
    exact ⟨fun ω hω => h ω (List.mem_append_left Ω₂ hω),
           fun ω hω => h ω (List.mem_append_right Ω₁ hω)⟩
  · rintro ⟨h1, h2⟩ ω hω
    cases List.mem_append.mp hω with
    | inl hm1 => exact h1 ω hm1
    | inr hm2 => exact h2 ω hm2

/-- Guard characterizations linking `evalGuard` directly to `denoteExpr = some v`. -/
theorem evalGuard_nonZero_iff (ρ : List Rat) (d : ExprQ0) :
    evalGuard ρ (.nonZero d) = true ↔ ∃ v : Rat, denoteExpr ρ d = some v ∧ v ≠ 0 := by
  unfold evalGuard
  cases hd : denoteExpr ρ d with
  | none => simp [hd]
  | some v => simp [hd]

theorem evalGuard_pos_iff (ρ : List Rat) (d : ExprQ0) :
    evalGuard ρ (.pos d) = true ↔ ∃ v : Rat, denoteExpr ρ d = some v ∧ 0 < v := by
  unfold evalGuard
  cases hd : denoteExpr ρ d with
  | none => simp [hd]
  | some v => simp [hd]

theorem evalGuard_nonNeg_iff (ρ : List Rat) (d : ExprQ0) :
    evalGuard ρ (.nonNeg d) = true ↔ ∃ v : Rat, denoteExpr ρ d = some v ∧ 0 ≤ v := by
  unfold evalGuard
  cases hd : denoteExpr ρ d with
  | none => simp [hd]
  | some v => simp [hd]

/-- Every satisfied guard guarantees its inner expression is defined (`isSome`). -/
theorem evalGuard_imp_isSome {ρ : List Rat} {ω : GuardQ0}
    (h : evalGuard ρ ω = true) : (denoteExpr ρ (guardExpr ω)).isSome = true := by
  cases ω with
  | nonZero d =>
      rcases (evalGuard_nonZero_iff ρ d).mp h with ⟨v, hd, _⟩
      simp [guardExpr, hd]
  | pos d =>
      rcases (evalGuard_pos_iff ρ d).mp h with ⟨v, hd, _⟩
      simp [guardExpr, hd]
  | nonNeg d =>
      rcases (evalGuard_nonNeg_iff ρ d).mp h with ⟨v, hd, _⟩
      simp [guardExpr, hd]

/-- Well-scoped expressions in a matching environment cannot fail variable lookup. -/
theorem bvar_denote_isSome_of_lt {ρ : List Rat} {i : Nat} (hi : i < ρ.length) :
    ∃ v : Rat, ρ[i]? = some v :=
  ⟨ρ[i], List.getElem?_eq_getElem hi⟩

/-! ### De Bruijn Weakening & Substitution Preservation for `denoteExpr` & `evalGuard` -/

theorem denoteExpr_liftExpr :
    ∀ (e : ExprQ0) (ρ₁ ρ_mid ρ₂ : List Rat),
      denoteExpr (ρ₁ ++ ρ_mid ++ ρ₂) (liftExpr ρ₁.length ρ_mid.length e) =
        denoteExpr (ρ₁ ++ ρ₂) e
  | .bvar i, ρ₁, ρ_mid, ρ₂ => by
      simp only [liftExpr]
      split
      · rename_i hlt
        have h := getElem?_append_middle ρ₁ ρ_mid ρ₂ i
        simp only [if_pos hlt] at h
        simpa [denoteExpr] using h
      · rename_i hge
        have h := getElem?_append_middle ρ₁ ρ_mid ρ₂ i
        simp only [if_neg hge] at h
        simpa [denoteExpr] using h
  | .ratLit _ _, _, _, _ => rfl
  | .unaryNeg a, ρ₁, ρ_mid, ρ₂ => by
      simp only [liftExpr, denoteExpr, denoteExpr_liftExpr a ρ₁ ρ_mid ρ₂]
  | .binOp op a b, ρ₁, ρ_mid, ρ₂ => by
      simp only [liftExpr, denoteExpr,
                 denoteExpr_liftExpr a ρ₁ ρ_mid ρ₂,
                 denoteExpr_liftExpr b ρ₁ ρ_mid ρ₂]
  | .letBind v body, ρ₁, ρ_mid, ρ₂ => by
      simp only [liftExpr, denoteExpr, denoteExpr_liftExpr v ρ₁ ρ_mid ρ₂]
      cases denoteExpr (ρ₁ ++ ρ₂) v with
      | none => rfl
      | some val_v =>
        dsimp only
        have hcons : val_v :: (ρ₁ ++ ρ_mid ++ ρ₂) = (val_v :: ρ₁) ++ ρ_mid ++ ρ₂ := rfl
        have hlen : ρ₁.length + 1 = (val_v :: ρ₁).length := rfl
        rw [hcons, hlen]
        exact denoteExpr_liftExpr body (val_v :: ρ₁) ρ_mid ρ₂

theorem denoteExpr_lift0_one (v₀ : Rat) (ρ : List Rat) (e : ExprQ0) :
    denoteExpr (v₀ :: ρ) (liftExpr 0 1 e) = denoteExpr ρ e := by
  have h := denoteExpr_liftExpr e [] [v₀] ρ
  simpa using h

theorem denoteExpr_substExpr :
    ∀ (e : ExprQ0) (ρ₁ ρ₂ : List Rat) (s : ExprQ0) (val_s : Rat),
      denoteExpr ρ₂ s = some val_s →
      denoteExpr (ρ₁ ++ ρ₂) (substExpr ρ₁.length s e) =
        denoteExpr (ρ₁ ++ val_s :: ρ₂) e
  | .bvar i, ρ₁, ρ₂, s, val_s, hs => by
      have hidx := getElem?_subst_at ρ₁ val_s ρ₂ i
      simp only [substExpr]
      split
      · rename_i hlt
        simp only [if_pos hlt] at hidx
        simpa [denoteExpr] using hidx.symm
      · rename_i hge
        simp only [if_neg hge] at hidx
        split
        · rename_i heq
          simp only [if_pos heq] at hidx
          have hlift := denoteExpr_liftExpr s [] ρ₁ ρ₂
          simp only [List.length_nil, List.nil_append] at hlift
          have rhs_eq : denoteExpr (ρ₁ ++ val_s :: ρ₂) (.bvar i) = some val_s := by
            simpa [denoteExpr] using hidx
          rw [rhs_eq]
          exact hlift.trans hs
        · rename_i hne
          simp only [if_neg hne] at hidx
          simpa [denoteExpr] using hidx.symm
  | .ratLit _ _, _, _, _, _, _ => rfl
  | .unaryNeg a, ρ₁, ρ₂, s, val_s, hs => by
      simp only [substExpr, denoteExpr, denoteExpr_substExpr a ρ₁ ρ₂ s val_s hs]
  | .binOp op a b, ρ₁, ρ₂, s, val_s, hs => by
      simp only [substExpr, denoteExpr,
                 denoteExpr_substExpr a ρ₁ ρ₂ s val_s hs,
                 denoteExpr_substExpr b ρ₁ ρ₂ s val_s hs]
  | .letBind v body, ρ₁, ρ₂, s, val_s, hs => by
      simp only [substExpr, denoteExpr, denoteExpr_substExpr v ρ₁ ρ₂ s val_s hs]
      cases denoteExpr (ρ₁ ++ val_s :: ρ₂) v with
      | none => rfl
      | some val_v =>
        dsimp only
        have hlen : ρ₁.length + 1 = (val_v :: ρ₁).length := rfl
        rw [hlen]
        exact denoteExpr_substExpr body (val_v :: ρ₁) ρ₂ s val_s hs

/-- Target Obligation `LEM-SubstDenote` (`M1-P0 R1` §1.2):
    When `denoteExpr ρ v = some val_v`, beta-substitution `subst0` and `substGuard0`
    preserve exact partial expression denotation and guard evaluation. -/
theorem lem_substDenote {ρ : List Rat} {v : ExprQ0} {val_v : Rat}
    (hv : denoteExpr ρ v = some val_v) :
    (∀ body : ExprQ0, denoteExpr ρ (subst0 v body) = denoteExpr (val_v :: ρ) body) ∧
    (∀ ω : GuardQ0, evalGuard ρ (substGuard0 v ω) = evalGuard (val_v :: ρ) ω) := by
  have hexpr : ∀ body : ExprQ0, denoteExpr ρ (subst0 v body) = denoteExpr (val_v :: ρ) body :=
    fun body => denoteExpr_substExpr body [] ρ v val_v hv
  refine ⟨hexpr, fun ω => ?_⟩
  cases ω with
  | nonZero d => simp only [substGuard0, evalGuard, hexpr d]
  | pos d     => simp only [substGuard0, evalGuard, hexpr d]
  | nonNeg d  => simp only [substGuard0, evalGuard, hexpr d]

theorem guardsHold_map_substGuard0 {ρ : List Rat} {v : ExprQ0} {val_v : Rat}
    (hv : denoteExpr ρ v = some val_v) (Ω : List GuardQ0) :
    GuardsHold ρ (Ω.map (substGuard0 v)) ↔ GuardsHold (val_v :: ρ) Ω := by
  have hsub := (lem_substDenote hv).2
  unfold GuardsHold
  simp only [List.mem_map]
  constructor
  · intro h ω hω
    have h1 := h (substGuard0 v ω) ⟨ω, hω, rfl⟩
    rw [hsub ω] at h1
    exact h1
  · intro h ω' ⟨ω, hω, heq⟩
    subst heq
    rw [hsub ω]
    exact h ω hω

/-- Explicit verification of Trap A (`M1-P0 R1` §1.1):
    `nonZero (x / x)` evaluates to `false` at `x = 0` rather than leaking `none ≠ some 0`. -/
theorem trapA_nested_div_zero_blocked :
    evalGuard [0] (.nonZero (.binOp .div (.bvar 0) (.bvar 0))) = false := by
  decide

end GrandZero.StageA
